# -*- coding: utf-8 -*-

# =============================================================================
# my_tkinter_project/
# │── main.py
# │── ui_components.py
# │── logic.py
# │── file_operations.py
# │── config.py
# =============================================================================


import tkinter as tk
# from tkinter import END, filedialog, messagebox
from tkinter import ttk, filedialog, DoubleVar
import pandas as pd
import os

from tkdial import Dial

# import subprocess

# import ttkbootstrap as ttk
# from ttkbootstrap import Style

import math
import numpy as np
import pandas as pd

# For excel
from openpyxl import load_workbook

from qcalc_2 import qc_implicit_tun
from strut import strut_correction_execution
from horizontal_buoyancy import horizontal_buyancy_execution

from wake_Distortion import wake_distortion_exe
# from Excel_writer_1 import save_to_excel
from ACBBL_up_2 import ACBBL_Execution
from tkdial import Meter

from PIL import Image, ImageTk

import logging

# ----------------------------------------------------------------------


# Default values for initialization


# Define the table data with values directly assigned to labels
Left_table_data = [
    {
        "Position": "Front-L",
        "Wheel Center": {"label": "Front-L Wheel Center", "value": 0},
        "Laser Distance": {"label": "Front-L Laser Distance", "value": 0},
        "Track Width": {"label": "Front-L Track Width", "value": 0},
        "Ride Height": {"label": "Front-L Ride Height", "value": None},
    },
    {
        "Position": "Front-R",
        "Wheel Center": {"label": "Front-R Wheel Center", "value": 0},
        "Laser Distance": {"label": "Front-R Laser Distance", "value": 0},
        "Track Width": {"label": "Front-R Track Width", "value": 0},
        "Ride Height": {"label": "Front-R Ride Height", "value": None},
    },
    {
        "Position": "Rear-L",
        "Wheel Center": {"label": "Rear-L Wheel Center", "value": 0},
        "Laser Distance": {"label": "Rear-L Laser Distance", "value": 0},
        "Track Width": {"label": "Rear-L Track Width", "value": 0},
        "Ride Height": {"label": "Rear-L Ride Height", "value": None},
    },
    {
        "Position": "Rear-R",
        "Wheel Center": {"label": "Rear-R Wheel Center", "value": 0},
        "Laser Distance": {"label": "Rear-R Laser Distance", "value": 0},
        "Track Width": {"label": "Rear-R Track Width", "value": 0},
        "Ride Height": {"label": "Rear-R Ride Height", "value": None},
    }
]

right_table_data = [

    {
        "Pressure Probe": "Static",
        "dd0": {"label": "Static dd0", "value": 1.21856e+002},
        "dd1": {"label": "Static dd1", "value": -5.11334e-003},
        "dd2": {"label": "Static dd1", "value": None},
    },

    {
        "Pressure Probe": "Nozzle",
        "dd0": {"label": "Primary dd0", "value": -3.30614e+000},
        "dd1": {"label": "Primary dd1", "value": 1.02503e+000},
        "dd2": {"label": "Primary dd2", "value": 0.000e+000},
    },

    {
        "Pressure Probe": "Plenum",
        "dd0": {"label": "Secondary dd0", "value": 9.87069e-001},
        "dd1": {"label": "Secondary dd1", "value": 1.01049e+000},
        "dd2": {"label": "Secondary dd2", "value": 0.000e+000},
    },
    {
        "Pressure Probe": "Collector",
        "dd0": {"label": "Collector dd0", "value": 0},
        "dd1": {"label": "Collector dd1", "value": 0},
        "dd2": {"label": "Collector dd2", "value": 0.000e+000},
    },

]

vehicle_geo_frame_data = {
    "Height - HM": 1.742,  # 1.645,
    "Length - LM": 5.514,  # 4.572,
    "Width - WM": 2.013,  # 2.179,
    "Frontal Area - FA": 3.041,  # 2.710,
    "Frontal Area - Override": 3.041,
    "Side Area - SA": 6.651,  # 5.488,
    "Volume": 10.140,  # 9.09,
    "Wheel Base - WB": 3.449,  # 2.860,
    "Front Overhang - FOB": 0.900,  # 0.86,
    "Rear Overhang - FOB": None,
}

wt_location_frame_data = {
    "Near Wake": 0,
    "XM": 4.067,  # 4.067,
    "XN": None,
    "XC": None,
    "X - Front Bumper": None,
    "X - Rear Bumper": None,
    "Cp - Front Bumper": None,
    "Cp - Rear Bumper": None,
    "Tunnel Factor": None,
    "Blockage Ratio": None,
    # "tau - Override": None,
}

strut_frame_data_00 = {
    "Configuration_00": 3,
    "Strut length_00": 4.063,
    "Strut length - Y axis_00": "NoShow 0",
    "Strut diameter_00": 0.104,
    "Strut angle_00": 30.9,
}

strut_frame_data_01 = {
    "Configuration_01": 3,
    "Strut length_01": 4.063,
    "Strut length - Y axis_01": "NoShow 0",
    "Strut diameter_01": 0.104,
    "Strut angle_01": -30.9,
}

strut_frame_data_10 = {
    "Configuration_10": 4,
    "Strut length_10": 2.083,
    "Strut length - Y axis_10": "NoShow 0",
    "Strut diameter_10": 0.104,
    "Strut angle_10": -90,
}

strut_frame_data_11 = {
    "Configuration_11": 3,
    "Strut length_11": 0,
    "Strut length - Y axis_11": "NoShow 0",
    "Strut diameter_11": 0.104,
    "Strut angle_11": 0.0,
}

# Add data to the left table
left_table_labels = {
    "Dynamic Pressure Nozzle": None,
    "Dynamic Pressure Plenum": None,
    "Dynamic Pressure Corrected": None,
    "Compresibility Test Section": None,
    "Primary Boundary Layer RS CFM": None,
    "Secondary Boundary Layer RS CFM": None,
    "Corrected Velocity (KMPH)": None,
    "Belt Speed (KMPH)": None,
    "Power (KW)": None,
    "Sensitivity Length, Xs": None,
}

right_table_labels = {
    "CD Nozzle": None,
    "CD Plenum": None,
    "CD Corrected": None,
    "CLF Corrected": None,
    "CLR Corrected": None,
    "CS Corrected": None,
    "ΔCD Dynamic Pressure": None,
    "ΔCD Horizontal Buoyancy": None,
    "ΔCD Strut Tare": None,
    "ΔCD Total": None,

}

vebtilation_drag_labels = {
    "On": "Box",
    "Low Speed Tare - Dmean": 0,
    "High Speed Tare - Dmean": 0,
    "LS/HS Ratio": "NoShow 0.1",
    "CD Ventilation": None,
}

wake_distortion_data = {
    "Dynamic Pressure": "Box",  # This should create a checkbox
    "Empty Pressure Gradient": 0,
    "Ramped Pressure Gradient": 0,
    "CD - Wake Distortion": None  # Read-only
}

wind_tunnel_parameter_data = {
    # "Run": None,
    # "Yaw": None,
    "Density": None,  # This should create a checkbox
    "Static Pressure": None,
    # "Volumetric Rate Set Point": None,
    "Tunnel Air Temperature (C)": None
    ,  # Dial 5
    "Relative Humidity": None,

}

# Dictionary to store Entry widgets
variables_all = {}  # default_values

variables_all_excel = {}

entry_widgets = {}

# ----------------------------------------------------------------------

import ttkbootstrap as ttk
from ttkbootstrap.constants import *

root = ttk.Window(themename="flatly")

root.title("Wind Tunnel Force Field Corrections")
root.geometry("1920x1200")  # Set a default size
root.update_idletasks()

variables_all["damp"] = 0.00
time_point = 0
run = 0

import logging

# Configure logging globally (call this once in your script)
logging.basicConfig(
    filename="LOG.txt",
    level=logging.INFO,
    format="%(asctime)s\n%(message)s\n",
    filemode="a"  # Append mode to prevent overwriting logs
)


def convert_numpy_types(value):
    """Convert NumPy types (int64, float64, arrays) to standard Python types for logging."""
    if isinstance(value, np.ndarray):
        return value.tolist()  # Convert NumPy arrays to Python lists
    elif isinstance(value, (np.int64, np.int32)):
        return int(value)  # Convert NumPy integers to Python int
    elif isinstance(value, (np.float64, np.float32)):
        return float(value)  # Convert NumPy floats to Python float
    return value  # Return as is if not a NumPy type


def format_nested_dict(data, indent=0):
    """Recursively formats a nested dictionary into a readable string."""
    formatted_lines = []

    for key, value in data.items():
        key_str = f"{' ' * indent}{key}"  # Apply indentation for nested levels

        if isinstance(value, dict):  # If value is a nested dictionary, recurse
            formatted_lines.append(f"{key_str}:")
            formatted_lines.extend(format_nested_dict(value, indent=indent + 4))
        else:
            value = convert_numpy_types(value)  # Convert NumPy types
            formatted_lines.append(f"{key_str}: {value}")

    return formatted_lines


def logging_action(variables_all):
    """Logs dictionary variables, including nested dictionaries, in a structured format to LOG.txt"""

    formatted_text = "\n".join(format_nested_dict(variables_all))

    # Log the formatted text
    logging.info("\n" + formatted_text)

    # Print confirmation
    print("Dictionary (including nested keys) logged successfully in LOG.txt")


# =============================================================================
# Calculation stage
# =============================================================================


# Blockage correction main function
def blockage_correction(df_selected_data, tunnel, method, Density, variables_all, Plotter):
    LM = float(variables_all["Length - LM"])
    WM = float(variables_all["Width - WM"])
    FA = float(variables_all["Frontal Area - FA"])
    SA = float(variables_all["Side Area - SA"])
    XM = float(variables_all["XM"])
    WB = float(variables_all["Wheel Base - WB"])
    FOH = float(variables_all["Front Overhang - FOB"])
    near_wake = float(variables_all["Near Wake"])
    volume = float(variables_all["Volume"])

    qN = df_selected_data["Dynamic_Press_Nozzle_Method"] * 47.880258888889
    qP = df_selected_data["Dynamic_Press_Plenum_Method"] * 47.880258888889
    yaw = df_selected_data["YAW"]
    CDU = df_selected_data["CD"]
    CSU = df_selected_data["CS"]
    DU = df_selected_data["D"]

    if dropdown4.get() == "0568-867-300-WSI":
        [corrected_dynamic_pressure, Correction_output, Vehicle_parameter_output, XSS_T, q00N_T,
         q00P_T] = qc_implicit_tun(tunnel, method, [qN], [qP], [yaw], [CDU], [CSU], LM, WM, FA, SA, XM, WB, FOH,
                                   near_wake, volume, Plotter, 0)
    else:
        [corrected_dynamic_pressure, Correction_output, Vehicle_parameter_output, XSS_T, q00N_T,
         q00P_T] = qc_implicit_tun(tunnel, method, [qN], [qP], [yaw], [CDU], [CSU], LM, WM, FA, SA, XM, WB, FOH,
                                   near_wake, volume, Plotter, 1)

    const = 4.4482216 / (corrected_dynamic_pressure * FA)
    corrected_velocity = math.sqrt(2 * corrected_dynamic_pressure / Density)  # meter/second

    if method == 0:
        const_2 = qN / corrected_dynamic_pressure
    else:
        const_2 = qP / corrected_dynamic_pressure

    # variables_all["Corrected Velocity"] = corrected_velocity

    update_readonly_entry("Corrected Velocity", corrected_velocity)

    update_readonly_entry("Corrected Velocity (KMPH)", corrected_velocity * 3.6)

    # Define the keys to apply the calculation
    keys_to_calculate = ["D", "L", "LF", "LR", "LLF", "LRF", "LLR", "LRR", "S", "SF", "SR"]

    # Loop over the keys and calculate the corrected values
    for key in keys_to_calculate:
        # corrected_key = f"C{key} Corrected - blockage"
        # update_readonly_entry(corrected_key, float(df_selected_data[key] * const))

        corrected_key = f"C{key} Corrected"
        update_readonly_entry(corrected_key, float(df_selected_data[key] * const))

        corrected_key_O = f"{key} Corrected - blockage"
        update_readonly_entry(corrected_key_O, float(df_selected_data[key] * const_2))

    dCd_DP = float(CDU - DU * const)

    ROFOB = FOH + WB

    XN = Vehicle_parameter_output["XN"]
    XC = Vehicle_parameter_output["XC"]
    Xs = Correction_output["Xs"]
    Qn = Correction_output["qNc"]
    Qp = Correction_output["qPc"]
    epsN = Correction_output["epsN"]
    epsS = Correction_output["epsS"]
    epsP = Correction_output["epsP"]
    epsC = Correction_output["epsC"]

    update_readonly_entry("Qn", float(Qn[0]))
    update_readonly_entry("Qp", float(Qp[0]))

    update_readonly_entry("XN", float(XN[0]))
    update_readonly_entry("XC", float(XC[0]))
    update_readonly_entry("Sensitivity Length, Xs", float(Xs[0]))
    update_readonly_entry("Epsilon-En", float(epsN[0]))
    update_readonly_entry("Epsilon-Ep", float(epsP[0]))
    update_readonly_entry("Epsilon-Ec", float(epsC[0]))
    update_readonly_entry("Dynamic Pressure Corrected", float(corrected_dynamic_pressure[0]))
    update_readonly_entry("Tunnel Factor", float(Vehicle_parameter_output["t"]))
    update_readonly_entry("Rear Overhang - FOB", float(ROFOB))

    update_readonly_entry("Blockage Ratio",
                          variables_all["Frontal Area - FA"] / float(Vehicle_parameter_output["A_Noz"]))

    if Plotter == 1:
        update_readonly_entry("Xs - array - Qcorr", (XSS_T[0, :]))
        update_readonly_entry("q00P - array - Qcorr", (q00P_T[0, :]))
        update_readonly_entry("q00N - array - Qcorr", (q00N_T[0, :]))

    update_readonly_entry("ΔCD Dynamic Pressure", float(dCd_DP))

    return dCd_DP, corrected_velocity, float(corrected_dynamic_pressure[0]), Correction_output, Vehicle_parameter_output


# Strut correction
def strut_correction(df_selected_data, tunnel, speed, variables_all):
    # Convert from meter/sec to miles/hour
    speed = speed * 2.23693629
    yaw = df_selected_data["YAW"]

    veh_yaw = yaw
    FA = float(variables_all["Frontal Area - FA"]) * 10.7639

    strut_data1 = [0, 0, 0, 0, 0]
    strut_data2 = [0, 0, 0, 0, 0]
    strut_data3 = [0, 0, 0, 0, 0]
    strut_data4 = [0, 0, 0, 0, 0]

    strut_data1[0] = float(variables_all["Configuration_00"])
    strut_data1[1] = float(variables_all["Strut length_00"]) * 12
    strut_data1[2] = float(variables_all["Strut length - Y axis_00"])
    strut_data1[3] = float(variables_all["Strut diameter_00"]) * 12
    strut_data1[4] = float(variables_all["Strut angle_00"])

    strut_data2[0] = float(variables_all["Configuration_01"])
    strut_data2[1] = float(variables_all["Strut length_01"]) * 12
    strut_data2[2] = float(variables_all["Strut length - Y axis_01"])
    strut_data2[3] = float(variables_all["Strut diameter_01"]) * 12
    strut_data2[4] = float(variables_all["Strut angle_01"])

    strut_data3[0] = float(variables_all["Configuration_10"])
    strut_data3[1] = float(variables_all["Strut length_10"]) * 12
    strut_data3[2] = float(variables_all["Strut length - Y axis_10"])
    strut_data3[3] = float(variables_all["Strut diameter_10"]) * 12
    strut_data3[4] = float(variables_all["Strut angle_10"])

    strut_data4[0] = float(variables_all["Configuration_11"])
    strut_data4[1] = float(variables_all["Strut length_11"]) * 12
    strut_data4[2] = float(variables_all["Strut length - Y axis_11"])
    strut_data4[3] = float(variables_all["Strut diameter_11"]) * 12
    strut_data4[4] = float(variables_all["Strut angle_11"])

    [strut_tare_total, _, _, _, _] = strut_correction_execution(veh_yaw, speed, FA, strut_data1, strut_data2,
                                                                strut_data3, strut_data4)

    update_readonly_entry("ΔCD Strut Tare", float(strut_tare_total))

    return strut_tare_total


def horizontal_buyancy_correction(variables_all):
    HM = float(variables_all["Height - HM"])
    LM = float(variables_all["Length - LM"])
    WM = float(variables_all["Width - WM"])
    FA = float(variables_all["Frontal Area - FA"])
    SA = float(variables_all["Side Area - SA"])
    XM = float(variables_all["XM"])
    WB = float(variables_all["Wheel Base - WB"])
    FOH = float(variables_all["Front Overhang - FOB"])
    near_wake = float(variables_all["Near Wake"])
    volume = float(variables_all["Volume"])

    [dCDHB, x_front_bmpr, x_rear_bmpr, cp_front, cp_rear, glauert] = horizontal_buyancy_execution(HM, LM, FA, SA,
                                                                                                  volume, WB, FOH, XM)

    update_readonly_entry("X - Front Bumper", float(x_front_bmpr))
    update_readonly_entry("X - Rear Bumper", float(x_rear_bmpr))
    update_readonly_entry("Cp - Front Bumper", float(cp_front))
    update_readonly_entry("Cp - Rear Bumper", float(cp_rear))
    update_readonly_entry("ΔCD Horizontal Buoyancy", -(float(dCDHB)))  # Check later

    return dCDHB, x_front_bmpr, x_rear_bmpr, cp_front, cp_rear, glauert


def calculation(variables_all_excel, variables_all, time_point, Plotter, Logging):
    global run

    run = run + 1

    tunnel = selected_option.get()
    method_density = selected_option3.get()

    A = selected_option2.get()
    if A == "Nozzle":
        method = 0
    else:
        method = 1

    if tunnel is not None:

        # Ensure that time_point exists in the values and handle non-indexable values
        df_selected_data = {
            key: value[time_point]
            for key, value in variables_all_excel.items()
            if isinstance(value, (list, tuple, pd.Series)) and len(value) > time_point
        }

        update_readonly_entry("df_selected_data", df_selected_data)

        imported_data = variables_all["df_selected_data"]

        update_readonly_entry("Belt Speed (KMPH)", df_selected_data["RRS_SPEED"] * 1.609344)
        update_readonly_entry("Primary Boundary Layer RS CFM", df_selected_data["PBLRS_Flow"])
        update_readonly_entry("Secondary Boundary Layer RS CFM", df_selected_data["SBLRS_Flow"])
        update_readonly_entry("Power (KW)", df_selected_data["Main_Fan_Actual_Power"])
        update_readonly_entry("Yaw", df_selected_data["YAW"])
        update_readonly_entry("Run", df_selected_data["Run Number"])

        CDU1 = imported_data["CD"]
        update_readonly_entry("Empty Pressure Gradient", CDU1)

        CDU2 = imported_data["CD2"]
        update_readonly_entry("Ramped Pressure Gradient", CDU2)

        if df_selected_data["Air Velocity"] > 0:

            # =============================================================================
            Laser_LF = float(imported_data["LFLASERCMD"])
            Laser_RF = float(imported_data["RFLASERCMD"])
            Laser_Rear = float(imported_data["REARLASERCMD"])

            FLH = float(variables_all["Front-L Laser Distance"]) + Laser_LF
            FRH = float(variables_all["Front-R Laser Distance"]) + Laser_RF
            RRH = float(variables_all["Rear-L Laser Distance"]) + Laser_Rear
            RLH = float(variables_all["Rear-R Laser Distance"]) + Laser_Rear

            update_readonly_entry("Front-L Ride Height", FLH)
            update_readonly_entry("Front-R Ride Height", FRH)
            update_readonly_entry("Rear-L Ride Height", RRH)
            update_readonly_entry("Rear-R Ride Height", RLH)
            # =============================================================================

            # =============================================================================
            Pressure = df_selected_data[method_density] * 249.08890833333
            Tc = (df_selected_data["Tunnel_Air_Temp"] - 32) * 5 / 9
            Tk = Tc + 273

            Re_Hum = df_selected_data["Relative_Humidity"] / 100

            e = (Re_Hum) * 100 * 6.11 * 10 ** ((7.5 * Tc) / (237.3 + Tc))

            Density = Pressure / (287.05 * Tk) * (1 - 0.3785 * (e / Pressure))
            # variables_all["Density"]=Density
            update_readonly_entry("Density", float(Density))
            # =============================================================================

            # =============================================================================
            [dCd_DP, corrected_velocity, corrected_dynamic_pressure, Correction_output,
             Vehicle_parameter_output] = blockage_correction(df_selected_data, tunnel, method, Density, variables_all,
                                                             Plotter)

            Drag_Force_damp = corrected_dynamic_pressure * variables_all["damp"] * variables_all["Frontal Area - FA"]
            update_readonly_entry("Drag Force - damp", float(Drag_Force_damp))

            strut_tare_total = strut_correction(df_selected_data, tunnel, corrected_velocity, variables_all)

            [dCDHB, x_front_bmpr, x_rear_bmpr, cp_front, cp_rear, glauert] = horizontal_buyancy_correction(
                variables_all)

            RolR_1 = float(variables_all_excel["D_Mean"][0]) * 4.44822162
            RolR_2 = float(variables_all_excel["D_Mean"][1]) * 4.44822162

            if RolR_1 == None or RolR_1 == 0:
                RolR_1 = variables_all["LS/HS Ratio"] * RolR_2
            else:
                update_readonly_entry("LS/HS Ratio", RolR_1 / RolR_2)

            Ventilation_Drag = (RolR_2 - RolR_1) / (
                        corrected_dynamic_pressure * float(variables_all["Frontal Area - FA"]))
            update_readonly_entry("CD Ventilation", Ventilation_Drag)
            update_readonly_entry("Low Speed Tare - Dmean", RolR_1)
            update_readonly_entry("High Speed Tare - Dmean", RolR_2)

            is_checked = entry_widgets["On"]["variable"].get()
            if is_checked == 1:
                vent_corr = Ventilation_Drag
            else:
                vent_corr = 0

            Total_CD = df_selected_data["CD"] - (dCd_DP) - abs(strut_tare_total) - abs(dCDHB) + abs(vent_corr) - \
                       variables_all["damp"]
            update_readonly_entry("ΔCD Total", float(df_selected_data["CD"] - Total_CD))
            update_readonly_entry("CD Corrected", float(Total_CD))
            update_readonly_entry("Velocity", corrected_velocity)
            # =============================================================================

            # =============================================================================
            dd0 = variables_all["Static dd0"]
            primary_dd0 = variables_all["Primary dd0"]
            secondary_dd0 = variables_all["Secondary dd0"]
            dd1 = variables_all["Static dd1"]
            primary_dd1 = variables_all["Primary dd1"]
            secondary_dd1 = variables_all["Secondary dd1"]
            primary_dd2 = variables_all["Primary dd2"]
            secondary_dd2 = variables_all["Secondary dd2"]

            dynp_meas_N = imported_data["Dynamic_Press_Nozzle_Method"] * 47.880258888889
            dynp_meas_P = imported_data["Dynamic_Press_Plenum_Method"] * 47.880258888889
            static_pres = Pressure
            tunnel_air_temp = Tk - 273
            rel_humidity = Re_Hum
            delta_Pp = imported_data[
                           "Plenum_Stilling_Chamber_Diff_Press"] / 0.0040146  # Measured value of pump differential pressure
            Area = imported_data["WTCS_SM"]
            rho = Density

            BL_results = ACBBL_Execution(dd0, dd1, primary_dd0, primary_dd1, primary_dd2, secondary_dd0, secondary_dd1,
                                         secondary_dd2, rho, method, dynp_meas_P, dynp_meas_N, static_pres,
                                         tunnel_air_temp, rel_humidity, delta_Pp, Area)

            # update_dials_from_BL_results(BL_results)

            update_readonly_entry("Boundary layer results", BL_results)
            update_readonly_entry("Static Pressure", BL_results["Static Pressure (Pa)"])
            update_readonly_entry("Boundary layer results", BL_results)
            update_readonly_entry("Tunnel Air Temperature (C)", BL_results["Tunnel Air Temperature (C)"])
            update_readonly_entry("Relative Humidity", BL_results["Relative Humidity"])
            update_readonly_entry("Volumetric Rate Set Point", BL_results["Volumetric Flow Rate Set Point"])
            update_readonly_entry("Pump Fan Speed Set Point", BL_results["Pump Fan Speed Set Point"])
            update_readonly_entry("Compresibility Test Section",
                                  BL_results["Compressible Test Section Dynamic Pressure (qts, Pa)"])
            # =============================================================================

            DPNM = imported_data["Dynamic_Press_Nozzle_Method"] * 47.880258888889
            DPPM = imported_data["Dynamic_Press_Plenum_Method"] * 47.880258888889

            update_readonly_entry("Dynamic Pressure Nozzle", DPNM)
            update_readonly_entry("Dynamic Pressure Plenum", DPPM)

            Force = imported_data["D"] * 4.4482216

            CD_U_N = Force / (DPNM * float(variables_all["Frontal Area - FA"])) - abs(strut_tare_total) - abs(dCDHB) - \
                     variables_all["damp"]
            CD_U_P = Force / (DPPM * float(variables_all["Frontal Area - FA"])) - abs(strut_tare_total) - abs(dCDHB) - \
                     variables_all["damp"]
            update_readonly_entry("CD Nozzle", float(CD_U_N))
            update_readonly_entry("CD Plenum", float(CD_U_P))

            update_dials_from_D1_R1_Recalc()

            save_button.configure(state="normal")
            compute_button.configure(state="normal")
            update_y_options(variables_all)
            # dropdown_plot.configure(state="readonly")
            dropdown_plot_x.config(state="readonly")
            dropdown_plot_y.config(state="readonly")

            Sync_CFD_Button.config(state="normal")
            Sync_Test_Button.config(state="normal")

            if Plotter == 1:
                plot_graph_frame_1()

            if run == 1:
                on_dropdown_change()

            # print("Logging", Logging)

            if Logging == 1:
                logging_action(variables_all)


def calculation_WD(variables_all, entry_widgets, Plotter):
    imported_data = variables_all["df_selected_data"]

    CDU1 = float(entry_widgets["Empty Pressure Gradient"].get())
    CDU2 = float(entry_widgets["Ramped Pressure Gradient"].get())

    XM = variables_all["XM"]
    WB = variables_all["Wheel Base - WB"]
    FOH = variables_all["Front Overhang - FOB"]

    is_checked = entry_widgets["Dynamic Pressure"]["variable"].get()

    if is_checked == 1:
        n = variables_all["Dynamic Pressure Corrected"] / (
                    imported_data["Dynamic_Press_Nozzle_Method"] * 47.880258888889)
    else:
        n = 1

    if dropdown5.get() == "Linear Interpolation":
        [cd_corrected, Xs_WD, target_x_values_array, CD_Dist1, CD_Dist2] = wake_distortion_exe(CDU1, CDU2, XM, WB, FOH,
                                                                                               n, Plotter, 1)
    else:
        [cd_corrected, Xs_WD, target_x_values_array, CD_Dist1, CD_Dist2] = wake_distortion_exe(CDU1, CDU2, XM, WB, FOH,
                                                                                               n, Plotter, 0)

    update_readonly_entry("CD - Wake Distortion", float(cd_corrected))

    update_readonly_entry("Xs - WD", float(Xs_WD))

    if CD_Dist1 is not None:
        update_readonly_entry("CD_Dist1 - WD", CD_Dist1)
        update_readonly_entry("CD_Dist2 - WD", CD_Dist2)
        update_readonly_entry("Xs - array - WD", target_x_values_array)

    plot_graph_frame_2()

    return cd_corrected


# =============================================================================
# Function to read .asc file and save into variables_all_excel
# =============================================================================

def select_asc_file():
    file_path = filedialog.askopenfilename(
        title="Select a .asc File",
        filetypes=[("ASC Files", "*.asc"), ("All Files", "*.*")]
    )

    if file_path:  # If a file is selected
        try:
            # Process the file using pandas
            df = pd.read_table(
                file_path,
                encoding='ISO-8859-1',
                # skiprows=[0, 1, 2, 4, 5, 6, 10],
                skiprows=[0, 1, 2, 4],
                usecols=range(1, 651)
            )

            for column in df.columns:
                variables_all_excel[column] = df[column]

            Sp = variables_all_excel["Air Velocity"]  # Assign the speed column

            # Initialize variables
            computables = []
            # Loop through the 'Sp' column
            for i in range(len(Sp)):
                value = Sp[i]
                if float(value) > 0:
                    computables.append(i)  # Add 1 to index to mimic MATLAB's 1-based indexing

            index_scroller.configure(
                values=computables,  # Restrict the scroller to only valid indices
                state="normal"  # Make it editable
            )
            index_scroller.set(computables[0])

            update_button.configure(
                state="normal"  # Make it editable
            )


        except Exception as e:
            # Handle errors during file processing
            print(f"Error while processing the file: {e}")
    else:
        print("No file selected.")

    return variables_all_excel


# %%
# =============================================================================
# Functions to update entry_widgets and variables_all


# Validation function for numeric input
def validate_numeric_input(value):
    try:
        float(value)  # Try to convert the value to a float
        return True
    except ValueError:
        return value == ""  # Allow empty input


# Register the validation function
validate_numeric = root.register(validate_numeric_input)
# Register the validation function
validate_numeric = root.register(validate_numeric_input)


# Update variables_all for entry input
def update_variables_all(event, label):
    global variables_all
    variables_all[label] = float(event.widget.get())  # Update the dictionary with the current value


# Function to update the read-only entry and variables_all
def update_readonly_entry(label, new_value):
    global variables_all
    global entry_widgets

    try:
        variables_all[label] = float(new_value)
    except:
        variables_all[label] = new_value

    if label in entry_widgets:
        entry = entry_widgets[label]
        initial_state = entry.cget("state")  # Get the current state

        entry.config(state="normal")  # Temporarily enable the Entry widget
        entry.delete(0, "end")  # Clear the current content
        entry.insert(0, new_value)  # Insert the new value

        if str(initial_state) == "readonly":
            entry.config(state="readonly")


def update_time_point_no(*args):
    global time_point
    global run
    time_point = index_var.get()  # Get the current spinbox value from the IntVar
    run = 0


# =============================================================================
# Add Photo
# =============================================================================

header_frame = tk.Frame(root, padx=10, pady=10)  # No LabelFrame (removes the boundary)
header_frame.grid(row=0, column=0, columnspan=10, padx=0, pady=0, sticky="ew")

# Load the image using PIL
image = Image.open("1-0.png")  # Use any image format (PNG, JPG, BMP)
image = image.resize((250, 75))  # Resize if needed
photo = ImageTk.PhotoImage(image)  # Store reference in a global variable

# Create a label and place it using grid()
image_label = tk.Label(header_frame, image=photo)
image_label.grid(row=0, column=0, columnspan=2, padx=10, pady=10)

# Create a frame for the header (No border)


import ttkbootstrap as tb
from ttkbootstrap.constants import *

# Create the header label using ttkbootstrap
header_label = tb.Label(
    header_frame,
    text="Scout Motors Digital Twin - Aerodynamic Wind Tunnel Force Field Solver  ",  # Header Text
    font=("Helvetica", 28, "bold"),  # Set Font Size and Style
    bootstyle="primary",  # ttkbootstrap style (e.g., primary, secondary, success, etc.)
    padding=10  # Padding for better appearance
)

# Use grid layout
header_label.grid(row=0, column=3, columnspan=3, padx=10, pady=10)


# =============================================================================
# Add a frames
# =============================================================================

def create_input_frame(master, title, data_dict, row, column, colspan=1):
    """
    Create a labeled frame with entry fields for input labels from a dictionary.

    Parameters:
    - root: Tkinter root or parent widget
    - title: Title of the LabelFrame
    - data_dict: Dictionary containing labels and their default values
    - row: Row position in the grid
    - column: Column position in the grid
    - colspan: Number of columns to span (default is 1)
    """

    global entry_widgets
    global variables_all

    frame = ttk.LabelFrame(master, text=title, padding=5)
    frame.grid(row=row, column=column, columnspan=colspan, padx=5, pady=5, sticky="ew")

    for i, (label, default_value) in enumerate(data_dict.items()):

        if default_value == "Box":
            ttk.Label(frame, text=label).grid(row=i, column=0, sticky="w", pady=2)
            var = tk.BooleanVar()
            widget = ttk.Checkbutton(frame, variable=var)

            widget.grid(row=i, column=1, padx=5, pady=2)

            entry_widgets[label] = {"widget": widget, "variable": var}


        elif isinstance(default_value, str) and default_value.startswith("NoShow"):
            # Extract numeric part after "NoShow" (e.g., "NoShow 93" -> 93)

            widget = ttk.Entry(
                frame,
                width=10,
                validate="key",
                validatecommand=(validate_numeric, "%P") if default_value is not None else None
            )

            try:
                numeric_value = float(default_value.split("NoShow")[1].strip())
                # widget.insert(0, str(numeric_value))
                variables_all[label] = numeric_value  # Store numeric value

            except ValueError:
                variables_all[label] = default_value  # If extraction fails, store as is

            entry_widgets[label] = widget  # Store reference

        else:

            ttk.Label(frame, text=label).grid(row=i, column=0, sticky="w", pady=2)
            widget = ttk.Entry(
                frame,
                width=10,
                validate="key",
                validatecommand=(validate_numeric, "%P")
            )

            if default_value is None:
                widget.config(state="readonly")
            else:
                widget.insert(0, str(default_value))
                widget.bind("<KeyRelease>", lambda event, lbl=label: update_variables_all(event, lbl))
                try:
                    variables_all[label] = float(widget.get())
                except:
                    variables_all[label] = widget.get()

            widget.grid(row=i, column=1, padx=5, pady=2)

            entry_widgets[label] = widget  # Store reference

    return frame  # Return frame if needed for additional elements


# =============================================================================
# Create input frames
create_input_frame(root, "Vehicle Geometry", vehicle_geo_frame_data, row=3, column=0)
create_input_frame(root, "Test Setion Fields", wt_location_frame_data, row=3, column=1)
create_input_frame(root, "Force Fields", left_table_labels, row=3, column=4)
create_input_frame(root, "Coefficients", right_table_labels, row=3, column=5)

strut_frame = ttk.LabelFrame(root, text="Strut Configuration", padding=5)
strut_frame.grid(row=3, column=2, columnspan=2, padx=5, pady=5, sticky="ew")

create_input_frame(strut_frame, "Strut FL", strut_frame_data_00, row=0, column=0)
create_input_frame(strut_frame, "Strut FR", strut_frame_data_01, row=0, column=1)
create_input_frame(strut_frame, "Strut RL", strut_frame_data_10, row=1, column=0)
create_input_frame(strut_frame, "Strut RR", strut_frame_data_11, row=1, column=1)

create_input_frame(root, "Wind Tunnel Air Properties", wind_tunnel_parameter_data, row=2, column=6)

# =============================================================================
# Add a wake distortion frame

frame_container = ttk.Frame(root)
frame_container.grid(row=3, column=6, padx=5, pady=5, sticky="ew")

# ======================== Wake Distortion Frame ==============================
frame_wake_dist = create_input_frame(frame_container, "Wake Distortion", wake_distortion_data, row=0, column=0,
                                     colspan=1)

# Ventilation Drag Frame
create_input_frame(frame_container, "Ventilation Drag", vebtilation_drag_labels, row=1, column=0, colspan=1)

# Compute button
compute_button = ttk.Button(
    frame_wake_dist,
    text="Compute",
    state="disabled",  # Initially disabled
    bootstyle=DANGER,
    command=lambda: calculation_WD(variables_all, entry_widgets, 1)
)
compute_button.grid(row=6, column=0, columnspan=2, pady=2)

# ======================== Calibration Slider Frame ==============================
frame_cal = ttk.Frame(frame_container, padding=5)
frame_cal.grid(row=3, column=0, sticky="ew", pady=5)  # Changed from pack() to grid()


# =============================================================================
# Put tables
# =============================================================================

def create_table(master, title, table_data, row, column, colspan, column_width):
    global entry_widgets
    global variables_all

    # Define column headers
    # headers = ["Position", "Wheel Center", "Laser Distance", "Track Width", "Ride Height"]

    frame = ttk.LabelFrame(master, text=title, padding=5)
    frame.grid(row=row, column=column, columnspan=colspan, padx=10, pady=10, sticky="ew")

    headers = list(table_data[0].keys())

    # Create column headers with fixed width
    for col_index, header in enumerate(headers):
        ttk.Label(frame, text=header, width=column_width).grid(
            row=0, column=col_index, padx=5, pady=5, sticky="w"
        )

    # Populate the table dynamically
    for row_index, row_data in enumerate(table_data, start=1):  # Start from 1 for headers
        for col_index, key in enumerate(headers):
            if isinstance(row_data[key], str):  # Handle "Position" separately
                ttk.Label(frame, text=row_data[key]).grid(
                    row=row_index, column=col_index, padx=0, pady=0, sticky="w"
                )
            else:
                label = row_data[key]["label"]
                value = row_data[key]["value"]

                entry = ttk.Entry(
                    frame,
                    width=column_width,
                    validate="key",
                    validatecommand=(validate_numeric, "%P")
                )

                if value == None:
                    entry.config(state="readonly")  # Make it readonly
                else:
                    # print("Label:", label, "value:", value)
                    entry.insert(0, value)
                    variables_all[label] = float(value)
                    entry.bind("<KeyRelease>", lambda event, lbl=label: update_variables_all(event, lbl))

                # Position the entry in the grid
                entry.grid(row=row_index, column=col_index, padx=5, pady=0)

                # Store references
                entry_widgets[label] = entry

    return frame


# =============================================================================
# Top 2 tables


create_table(root, "", Left_table_data, 2, 0, 2, 11)

create_table(root, "", right_table_data, 2, 2, 2, 13)

#
# =============================================================================


# =============================================================================
# Put drop downs
# =============================================================================

# Create a frame to hold all the dropdown menus


# Create the frame spanning three columns
dropdown_frame = ttk.LabelFrame(root, text="", padding=5)
dropdown_frame.grid(row=1, column=4, padx=10, pady=10, sticky="ew", columnspan=3)

# =============================================================================
# Dropdown 1 - Wind Tunnel
selected_option = tk.StringVar()
options = ["WSI", "WT8", "AAWT"]
dropdown_label = ttk.Label(dropdown_frame, text="Wind Tunnel")
dropdown_label.grid(row=0, column=0, padx=5, pady=2, sticky="w")

dropdown = ttk.Combobox(dropdown_frame, textvariable=selected_option, values=options, state="readonly")
dropdown.grid(row=1, column=0, padx=5, pady=0, sticky="ew")
dropdown.set(options[0])  # Default selection

# =============================================================================
# Dropdown 2 - Calculation Method
selected_option4 = tk.StringVar()
options4 = ["0568-867-300-WSI", "J2281"]
dropdown_label4 = ttk.Label(dropdown_frame, text="Correction Method")
dropdown_label4.grid(row=0, column=1, padx=5, pady=2, sticky="w")

dropdown4 = ttk.Combobox(dropdown_frame, textvariable=selected_option4, values=options4, state="readonly")
dropdown4.grid(row=1, column=1, padx=5, pady=0, sticky="ew")
dropdown4.set(options4[0])  # Default selection

# =============================================================================
# Dropdown 3 - Method
selected_option2 = tk.StringVar()
options2 = ["Nozzle", "Plenum"]
dropdown_label2 = ttk.Label(dropdown_frame, text="Air Calibration")
dropdown_label2.grid(row=0, column=2, padx=5, pady=2, sticky="w")

dropdown2 = ttk.Combobox(dropdown_frame, textvariable=selected_option2, values=options2, state="readonly")
dropdown2.grid(row=1, column=2, padx=5, pady=0, sticky="ew")
dropdown2.set(options2[1])  # Default selection

# =============================================================================
# Dropdown 4 - Density Calculation
selected_option3 = tk.StringVar()
options3 = ["Static_Press_A", "Static_Press_B", "PS_CORR_A", "PS_CORR_B"]
dropdown_label3 = ttk.Label(dropdown_frame, text="Pressure Measurement")
dropdown_label3.grid(row=0, column=3, padx=5, pady=2, sticky="w")

dropdown3 = ttk.Combobox(dropdown_frame, textvariable=selected_option3, values=options3, state="readonly")
dropdown3.grid(row=1, column=3, padx=2, pady=0, sticky="ew")
dropdown3.set(options3[1])  # Default selection

# =============================================================================
# Dropdown 5 - Distortion Method (Fixed Issue)
selected_option5 = tk.StringVar()  # Use a new variable for dropdown5
options5 = ["Brute Force", "Linear Interpolation"]
dropdown_label5 = ttk.Label(dropdown_frame, text="Distortion Method")
dropdown_label5.grid(row=0, column=4, padx=5, pady=2, sticky="w")

dropdown5 = ttk.Combobox(dropdown_frame, textvariable=selected_option5, values=options5, state="readonly")
dropdown5.grid(row=1, column=4, padx=2, pady=0, sticky="ew")
dropdown5.set(options5[0])  # Corrected default selection

# =============================================================================
# Add a frame for the controls
# =============================================================================

# Configure button frame

# Configure button frame (Single Row Layout)
button_frame = ttk.LabelFrame(root, text="", padding=5)
button_frame.grid(row=1, column=0, columnspan=4, padx=10, pady=0, sticky="ew")  # No rowspan

# Ensure columns expand evenly
for i in range(6):  # Adjusted for 6 elements (buttons + scroller)
    button_frame.columnconfigure(i, weight=1)

# Import button
import_button = ttk.Button(
    button_frame,
    text="Import D1_R_Recalc.asc",
    command=lambda: variables_all_excel.update({"selected_file": select_asc_file()}),
)
import_button.grid(row=0, column=0, padx=5, pady=2, sticky="ew")  # Ensures alignment

# Compute button
update_button = ttk.Button(
    button_frame,
    text="Compute",
    state="disabled",
    bootstyle="SUCCESS",
    command=lambda: calculation(variables_all_excel, variables_all, time_point, 1, 1),
)
update_button.grid(row=0, column=1, padx=(0, 0), pady=2, sticky="ew")  # No gap

# Scroller (Spinbox) - Positioned Right Next to Compute Button
index_var = tk.IntVar(value=0)
index_scroller = ttk.Spinbox(
    button_frame,
    from_=0,
    to=0,
    textvariable=index_var,
    state="disabled",
    wrap=True,
    width=3,  # Small size
    justify="center",
)
index_scroller.grid(row=0, column=2, padx=(0, 0), pady=2, sticky="ew")  # No gap with Compute

# Bind the Spinbox value change to the handler
index_var.trace_add("write", update_time_point_no)

# Save button
save_button = ttk.Button(
    button_frame,
    text="Save",
    command=lambda: save_to_excel(index_scroller, update_button, variables_all),
    state="disabled",
    bootstyle="WARNING",
)
save_button.grid(row=0, column=3, padx=5, pady=2, sticky="ew")  # Correct position

# Sync to CFD Button
Sync_CFD_Button = ttk.Button(
    button_frame,
    text="Sync with Simulation",
    state="disabled",
    bootstyle="Primary",
)
Sync_CFD_Button.grid(row=0, column=4, padx=5, pady=2, sticky="ew")  # Correct position

# Sync to Test Button
Sync_Test_Button = ttk.Button(
    button_frame,
    text="Sync with Test Setup",
    state="disabled",
    bootstyle="INFO",
)
Sync_Test_Button.grid(row=0, column=5, padx=5, pady=2, sticky="ew")  # Correct position

# =============================================================================
# # Create main window

import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

plt.rcParams.update({
    "font.size": 5,  # Reduce default font size
    "axes.titlesize": 5,  # Title font size
    "axes.labelsize": 5,  # X and Y label size
    "xtick.labelsize": 5,  # X-axis tick size
    "ytick.labelsize": 5,  # Y-axis tick size
    "legend.fontsize": 5  # Legend font size
})


def plot_graph_frame_1():
    ax.clear()
    x = variables_all["Xs - array - Qcorr"]
    y1 = variables_all["q00N - array - Qcorr"]
    y2 = variables_all["q00P - array - Qcorr"]

    # Clear previous plot (if any)
    ax.plot(x, y1, label="qN * (1 + epsilonN) ** 2")
    ax.plot(x, y2, label="qP * (1 + epsilonP) ** 2")

    ax.axvline(x=variables_all["Sensitivity Length, Xs"], color="red", linestyle="--", linewidth=2, label="Xs")

    ax.set_xlabel("Sensitivity Length, Xs")
    ax.set_ylabel("Error value")
    # ax.set_title("epsilonN and epsilonP vs Xs")

    # Ensure legend is added and properly updated
    ax.legend(loc="best", fontsize=5, frameon=True)

    # Autoscale axes based on the new data
    ax.relim()
    ax.autoscale_view()

    # Adjust layout to prevent label cutoff
    fig.tight_layout()

    # Update the correct canvas
    canvas.draw()
    canvas.flush_events()


# Function to plot
def plot_graph_frame_2():
    ax2.clear()

    x = variables_all["Xs - array - WD"]
    y1 = variables_all["CD_Dist1 - WD"]
    y2 = variables_all["CD_Dist2 - WD"]

    ax2.plot(x, y1, label="Distribution 1")
    ax2.plot(x, y2, label="Distribution 2")

    # ax2.axvline(x=variables_all["Xs - WD"], color="red", linestyle="--", linewidth=2, label="Xs")

    CD_WD = variables_all["CD - Wake Distortion"]
    ax2.scatter(variables_all["Xs - WD"], CD_WD, s=10, facecolors='none', edgecolors='red', linewidth=2)

    # ax2.text(variables_all["Xs - WD"], CD_WD, f'Intersection at ({variables_all["Xs - WD"]:.4f}, {CD_WD:.4f})', fontsize=9, verticalalignment='bottom')

    # plt.xlim(0,10)  # X-axis limit
    ax2.set_ylim(CD_WD - CD_WD * 0.02, CD_WD + CD_WD * 0.02)

    # ax2.grid(True)

    ax2.set_xlabel("Distance from nozzle")
    ax2.set_ylabel("CDc")
    # ax2.set_title("epsilonN and epsilonP vs Xs")

    # Autoscale axes based on the new data
    ax2.relim()
    ax2.autoscale_view()

    # Adjust layout to prevent label cutoff
    fig2.tight_layout()

    # Update the correct canvas
    canvas2.draw()
    canvas2.flush_events()


# Function to plot
def plot_graph_frame_3(x, y, xC, yC, xLabel, yLabel):
    ax3.clear()

    ax3.plot(x, y)
    ax3.set_xlabel(xLabel)
    ax3.set_ylabel(yLabel)

    ax3.scatter(xC, yC, s=10, facecolors='none', edgecolors='red', linewidth=2)

    # Ensure legend is added and properly updated
    # ax3.legend(loc="best", fontsize=9, frameon=True)

    # Autoscale axes based on the new data
    ax3.relim()
    ax3.autoscale_view()

    # Adjust layout to prevent label cutoff
    fig3.tight_layout()

    # Update the correct canvas
    canvas3.draw()
    canvas3.flush_events()


# Create a frame for the plot and place it using grid
frame_plot = ttk.Frame(root, padding=5)
frame_plot.grid(row=4, column=0, columnspan=7, rowspan=2, padx=0, pady=10, sticky="nsew")

# Create figure and axis
fig, ax = plt.subplots(figsize=(3, 2))

# Create canvas to embed plot
canvas = FigureCanvasTkAgg(fig, master=frame_plot)
canvas_widget = canvas.get_tk_widget()
canvas_widget.grid(row=0, column=0, sticky="nsew")

# =============================================================================
# Create a frame for the plot and place it using grid
# frame_plot2 = ttk.Frame(root)
# frame_plot2.grid(row=3, column=2, columnspan=2, rowspan=2, padx=10, pady=10, sticky="nsew")

# Create figure and axis
fig2, ax2 = plt.subplots(figsize=(3, 2))

# Create canvas to embed plot
canvas2 = FigureCanvasTkAgg(fig2, master=frame_plot)
canvas_widget2 = canvas2.get_tk_widget()
canvas_widget2.grid(row=0, column=1, sticky="nsew")

# Create figure and axis
fig3, ax3 = plt.subplots(figsize=(3, 2))

# Create canvas to embed plot
canvas3 = FigureCanvasTkAgg(fig3, master=frame_plot)
canvas_widget3 = canvas3.get_tk_widget()
canvas_widget3.grid(row=0, column=2, sticky="nsew")


# =============================================================================


# =============================================================================
# Create a StringVar to hold the selected value

# Function to disable the entire application
def disable_app():
    root.attributes("-disabled", True)
    root.update_idletasks()  # Update UI


# Function to enable the entire application
def enable_app():
    root.attributes("-disabled", False)


def data_array_generator(x_option_C, y_option_C, X, Y):
    if x_option_C == 0:
        x_range = np.linspace(0, 1, 64)  # 10 points for example
    else:
        x_range = np.linspace(x_option_C - x_option_C / 2, x_option_C + x_option_C / 2, 64)  # 10 points for example

    y_range = np.zeros_like(x_range)  # Creates an array of zeros

    i = 0
    for value in x_range:
        update_readonly_entry(X, value)
        # update_button_No_plotting_logging.invoke()

        calculation(variables_all_excel, variables_all, time_point, 1, 0)

        y_range[i] = float(variables_all[Y])
        i = i + 1

    return x_range, y_range


# Function to handle dropdown changes
def on_dropdown_change(event=None):
    # selected_x = selected_option_plot_x.get()
    # selected_y = selected_option_plot_y.get()

    X = dropdown_plot_x.get()
    Y = dropdown_plot_y.get()

    if X != "Independent variable" and Y != "Dependent variable":
        disable_app()

        x_option_C = float(variables_all[X])
        y_option_C = float(variables_all[Y])

        [x_range, y_range] = data_array_generator(x_option_C, y_option_C, X, Y)

        # update_readonly_entry("x - array - plot", x_range)
        # update_readonly_entry("y - array - plot", y_range)

        update_readonly_entry(X, x_option_C)
        calculation(variables_all_excel, variables_all, time_point, 1, 0)

        plot_graph_frame_3(x_range, y_range, x_option_C, y_option_C, X, Y)

        enable_app()


selected_option_plot_x = tk.StringVar()

# Create a dropdown menu (Combobox) with the options
options_plot_x = list(variables_all.keys())

dropdown_plot_x = ttk.Combobox(frame_plot, textvariable=selected_option_plot_x, values=options_plot_x, state="disabled")
dropdown_plot_x.grid(row=0, column=2, padx=10, pady=5, sticky="n")

# Set a default selection
dropdown_plot_x.set("Independent variable")  # Default placeholder

dropdown_plot_x.set("XM")  # Default placeholder

# Bind selection change to function
dropdown_plot_x.bind("<<ComboboxSelected>>", on_dropdown_change)
# dropdown_plot_x.set(options_plot_x[0])


# =============================================================================
# Create a StringVar to hold the selected value

# Initialize options list
options_plot_y = ["Dependent variable"]  # Initial options
selected_option_plot_y = tk.StringVar()

# Create the dropdown menu (Combobox)
dropdown_plot_y = ttk.Combobox(frame_plot, textvariable=selected_option_plot_y, values=options_plot_y, state="disabled")
dropdown_plot_y.grid(row=0, column=2, padx=5, pady=5, sticky="ne")

# Set a default selection
if options_plot_y:
    dropdown_plot_y.set("CD Corrected")  # Set to first option if available


# Function to update the dropdown menu dynamically
def update_y_options(variables_all):
    global options_plot_y
    global options_plot_x
    # new_options = ["Pressure", "Temperature", "Velocity", "Density"]  # New dynamic options

    # Extract non-empty entries for new_options
    new_options = [
        key for key, value in variables_all.items()
        if isinstance(value, (float, int, str, np.number)) and value  # Ensures valid types and non-empty
    ]

    # Subtract options_plot_x from new_options
    # filtered_options = [key for key in new_options if key not in options_plot_x]

    # Alternative using set difference (More efficient)
    filtered_options_set = list(set(new_options) - set(options_plot_x))

    options_plot_y = filtered_options_set  # Update the global variable
    dropdown_plot_y.config(values=options_plot_y)  # Update Combobox values

    # Reset selection if needed
    # if filtered_options_set:
    #     dropdown_plot_y.set(filtered_options_set[0])  # Select first item


# Bind event to dropdown selection change
dropdown_plot_y.bind("<<ComboboxSelected>>", update_y_options)
# Bind selection change to function
dropdown_plot_y.bind("<<ComboboxSelected>>", on_dropdown_change)

# =============================================================================
# Generic plotter
# =============================================================================

# Create a frame for dials
frame_dial = ttk.LabelFrame(root, text="", padding=5)
frame_dial.grid(row=2, column=4, columnspan=2, rowspan=1, padx=5, pady=2, sticky="nsew")

meter0 = Meter(frame_dial, radius=120, start=0, end=200, border_width=0,
               fg="black", text_color="white", start_angle=270, end_angle=-320,
               text_font="DS-Digital 0", scale_color="white", needle_color="red")
meter0.set_mark(180, 300)  # set red marking from 140 to 160
meter0.grid(row=0, column=0, padx=5, pady=5)

meter1 = Meter(frame_dial, fg="#242424", radius=120, start=0, end=2000,
               major_divisions=200, border_width=0, text_color="white",
               start_angle=270, end_angle=-270, scale_color="white", axis_color="cyan",
               needle_color="white", scroll_steps=10)
meter1.set(0)
meter1.grid(row=0, column=1, padx=5, pady=0)

meter2 = Meter(frame_dial, radius=110, start=0, end=250, border_width=5,
               fg="black", text_color="white", start_angle=270, end_angle=-360,
               text_font="DS-Digital 0", scale_color="black", axis_color="white",
               needle_color="white")
meter2.set_mark(1, 140, "#92d050")
meter2.set_mark(145, 200, "yellow")
meter2.set_mark(205, 250, "red")
meter2.set(0)  # set value
meter2.grid(row=0, column=2, padx=5, pady=5)

meter3 = Meter(frame_dial, radius=110, start=0, end=250, border_width=5,
               fg="black", text_color="white", start_angle=270, end_angle=-360,
               text_font="DS-Digital 0", scale_color="black", axis_color="white",
               needle_color="white")
meter3.set_mark(1, 140, "#92d050")
meter3.set_mark(145, 200, "yellow")
meter3.set_mark(205, 250, "red")
meter3.set(0)  # set value
meter3.grid(row=0, column=3, padx=5, pady=5)

# Labels below each meter
labels = ["Main Fan RPM", "Drag Force N", "Air Speed Nozzle KPH", "Air Speed Plenum KPH"]

for i, text in enumerate(labels):
    ttk.Label(frame_dial, text=text, foreground="black").grid(row=1, column=i, pady=2)


def update_dials_from_D1_R1_Recalc():
    global variables_all

    Density = variables_all["Density"]

    imported_data = variables_all["df_selected_data"]

    meter0.set(imported_data["Main_Fan_Actual_Speed_Fbk"])

    DForce_DF = variables_all["Drag Force - damp"]
    D = imported_data["D"] * 4.44822

    meter1.set(D - DForce_DF)

    qN = imported_data["Dynamic_Press_Nozzle_Method"] * 47.880258888889
    qP = imported_data["Dynamic_Press_Plenum_Method"] * 47.880258888889
    air_speed_nozzle = math.sqrt(2 * qN / Density)*3.6  # meter/second
    air_speed_plenum = math.sqrt(2 * qP / Density)*3.6  # meter/second
    meter2.set(air_speed_nozzle)

    meter3.set(air_speed_plenum)


import pandas as pd
import os
import subprocess

import math
import numpy as np
import pandas as pd

# For excel
from openpyxl import load_workbook
from tkinter import END, filedialog, messagebox


# from tabulate import tabulate  # Install with: pip install tabulate

# from tablegui_R1 import TableViewer

# =============================================================================
# Function to read .asc file and save into variables_all_excel
# =============================================================================

def save_to_excel(index_scroller, update_button, variables_all):
    # Ask for a file path to save the Excel file
    file_path = filedialog.asksaveasfilename(
        defaultextension=".xlsx",
        filetypes=[("Excel files", "*.xlsx"), ("All files", "*.*")]
    )

    if not file_path:
        return  # User canceled the save dialog

    # Generate a unique CSV file path
    base_csv_path = os.path.splitext(file_path)[0]  # Remove extension
    csv_file_path = get_unique_filename(base_csv_path, ".csv")

    # Get range as integers
    Range = list(map(int, index_scroller["values"]))  # Convert values to integers
    current_value = min(Range)  # Get the minimum value
    index_scroller.set(current_value)  # Set the Spinbox to the minimum value

    count = 0
    for i in Range:
        # Simulate button press and GUI update
        # print(f"Simulating button press for value: {i}")

        update_button.invoke()

        imported_data = variables_all["df_selected_data"]

        # =============================================================================
        configuration_text = ""  # text_box.get("1.0", "end").strip()
        if count == 0:
            initial_data = {
                "Run": imported_data["Run Number"],
                "Configuration": configuration_text,
            }
        else:
            initial_data = {
                "Run": None,
                "Configuration": None,
            }
        filtered_data = initial_data

        # =============================================================================
        corrected_data_1 = {
            "Point": i,
            "Yaw": imported_data["YAW"],
            "Vcorr": variables_all["Corrected Velocity"] * 3.6,
        }

        # "Dynamic pressure Corrected - blockage": variables_all["Dynamic Pressure Corrected"],

        filtered_data.update(corrected_data_1)

        corrected_data_2 = {
            "CD": variables_all["CD Corrected"],
            "CLF": variables_all["CLF Corrected"],
            "CLR": variables_all["CLR Corrected"],
            "CLLF": variables_all["CLLF Corrected"],
            "CLRF": variables_all["CLRF Corrected"],
            "CLLR": variables_all["CLLR Corrected"],
            "CLRR": variables_all["CLRR Corrected"],
            "CL": variables_all["CL Corrected"],
            "CSF": variables_all["CSF Corrected"],
            "CSR": variables_all["CSR Corrected"],
            "CS": variables_all["CS Corrected"],
        }
        filtered_data.update(corrected_data_2)

        corrected_data_3 = {
            "Qcorr": variables_all["Dynamic Pressure Corrected"],
            "qcN/qm": imported_data["Dynamic_Press_Nozzle_Method"] / imported_data["Dynamic_Press_Plenum_Method"],
            "qcP/qm": variables_all["Dynamic Pressure Corrected"] / imported_data["Dynamic_Press_Plenum_Method"],
            "DelStrutC": variables_all["ΔCD Strut Tare"],
            "HBC": variables_all["ΔCD Horizontal Buoyancy"],
            "Vm": imported_data["Air Velocity"] * 1.60934
        }

        filtered_data.update(corrected_data_3)

        corrected_data_4 = {
            "LF": variables_all["Front-L Ride Height"],
            "RF": variables_all["Front-R Ride Height"],
            "LR": variables_all["Rear-L Ride Height"],
            "RR": variables_all["Rear-R Ride Height"],
        }

        filtered_data.update(corrected_data_4)

        corrected_data_5 = {
            "Del-CD": None,
            "Del-CLF": None,
            "Del-CLR": None,
            "Del-CLLF": None,
            "Del-CLRF": None,
            "Del-CLLR": None,
            "Del-CLRR": None,
            "Del-CL": None,
            "Del-CSF": None,
            "Del-CSR": None,
            "Del-CS": None,
            "Del-Qcorr": None,
        }

        filtered_data.update(corrected_data_5)

        # Convert the filtered dictionary to a DataFrame
        df_to_write = pd.DataFrame([filtered_data])

        # =============================================================================
        # Write to CSV file

        # df_to_write.to_csv(csv_file_path, index=False, mode='w')

        if count == 0 and not os.path.exists(csv_file_path):
            # Write CSV headers only for the first iteration
            df_to_write.to_csv(csv_file_path, index=False, mode='w')
        else:
            # Append without headers for subsequent iterations
            df_to_write.to_csv(csv_file_path, index=False, mode='a', header=False)

        # =============================================================================
        # Write to Excel file
        if os.path.exists(file_path):
            # Append to the existing Excel file
            with pd.ExcelWriter(file_path, mode='a', engine='openpyxl', if_sheet_exists='overlay') as writer:
                # Get the last row in the existing Excel sheet
                book = load_workbook(file_path)
                sheet = book.active  # Get the active sheet
                start_row = sheet.max_row  # Determine the starting row for appending

                if count == 0:
                    # Create a blank row (as a DataFrame)
                    blank_row = pd.DataFrame([None] * len(df_to_write.columns)).T
                    blank_row.columns = df_to_write.columns  # Match the column headers

                    blank_row.to_excel(writer, index=False, header=False, startrow=start_row)
                    # Write the DataFrame to the Excel file
                    df_to_write.to_excel(writer, index=False, header=False, startrow=start_row + 1)

                else:
                    df_to_write.to_excel(writer, index=False, header=False, startrow=start_row)

        else:
            # For the first iteration, write with headers
            df_to_write.to_excel(file_path, index=False, startrow=10)

        count += 1

        # time.sleep(1)  # Wait for 1 second
        if current_value < max(Range):  # Check range bounds
            current_value += 1
            index_scroller.set(current_value)  # Update Spinbox value

    # Ensure the file exists before launching
    if os.path.exists(csv_file_path):
        # Launch GUI_Table.py with the CSV file as an argument
        subprocess.Popen(["python", "GUI_Table.py", csv_file_path])

    # print(csv_file_path)


def get_unique_filename(base_path, extension):
    """Generate a unique filename by appending a number if the file already exists."""
    counter = 1
    new_path = f"{base_path}{extension}"

    # Keep incrementing the number until we find a unique filename
    while os.path.exists(new_path):
        new_path = f"{base_path}_{counter}{extension}"
        counter += 1

    return new_path


image1 = Image.open("1-1.jpg")  # Ensure this file exists in the correct path
image1 = image1.resize((475, 185))  # Resize if needed

# Convert to Tkinter-compatible image format
photo1 = ImageTk.PhotoImage(image1)  # Store reference globally

# Update or create image label
try:
    image_label1.config(image=photo1)  # Update existing label if it exists
    image_label1.image = photo1  # Prevent garbage collection
except NameError:
    # If image_label1 does not exist, create it
    image_label1 = tk.Label(root, image=photo1)
    image_label1.grid(row=4, column=5, columnspan=10, padx=20, pady=20)

# Create a footer frame with ttkbootstrap info-colored style
footer_frame = ttk.Frame(root, padding=(10, 10))
footer_frame.grid(row=5, column=0, columnspan=5, padx=0, pady=0, sticky="ew")

# Footer text label with ttkbootstrap styling
footer_label1 = ttk.Label(
    footer_frame,
    text="TECHNICAL PAPER REFERENCES:\n"
         "• J2881_201910 - Measurement of Aerodynamic Performance for Mass-Produced Cars and Light-Duty Trucks\n"
         "• 2006-01-0568 - A Two-Measurement Correction for the Effects of a Pressure Gradient on Automotive\n"
         "• 2005-01-0867 - Horizontal Pressure Distribution on Aerodynamic Drag in Open and Closed Wind Tunnels\n"
         "• 2004-01-0670 - Further Investigations on Gradient Effects\n"
         "• 2012-01-0300 - The Windshear Rolling Road Wind Tunnel\n",
    justify="left",
    bootstyle="primary"  # Ensures text blends into the frame
)
footer_label1.grid(row=0, column=0, columnspan=5, padx=10, pady=10, sticky="w")

# Expand frame width to fill the parent container
footer_frame.columnconfigure(0, weight=1)

# Create a footer frame with ttkbootstrap info-colored style
footer_frame = ttk.Frame(root, padding=(10, 10))
footer_frame.grid(row=5, column=3, columnspan=5, padx=0, pady=0, sticky="ew")
# Footer text label
footer_label2 = ttk.Label(
    footer_frame,
    text="MEMORANDUM - WINDSHEAR INC:\n"
         "• Boundary Layer Characterization - Katlynn Bringhurst | September 14, 2022\n"
         "• Airspeed Calibration Report - Katlynn Bringhurst | November 4, 2022\n"
         "• Restraint Strut Drag Tares - Joel Walter - February 01, 2012\n"
         "• Windshear Standard Data Reductions - Revision 3.1.1 - October 30, 2020\n"
         "• European Aerodynamic Data Exchange Test Log - CHART NO. / REV. 1.1\n",
    justify="left",  # Ensure text remains left-justified
    bootstyle="primary"  # Ensures text blends into the frame
)
footer_label2.grid(row=0, column=0, columnspan=5, padx=10, pady=10, sticky="w")

# Create a footer frame with ttkbootstrap info-colored style
footer_frame = ttk.Frame(root, padding=(10, 10))
footer_frame.grid(row=5, column=5, columnspan=5, padx=0, pady=0, sticky="ew")
# Footer text label
footer_label3 = ttk.Label(
    footer_frame,
    text="MEMORANDUM - SCOUT MOTORS INC:\n"
         "• Wind Tunnel Correction Procedures - Vasantha Jayasankaran | August 20, 2024\n"
         "• Flow Field DAq Procedures - Umachandran Muralidharan | January 14, 2025\n"
         "• CFD - Test Data Characterization - Adnan & Rahul  | November 19, 2024\n"
         "• Ventiation Drag Tares - CFD - Trevor Blohm | November 19, 2024 \n"
         "© 2025 Scout Digital Twin Aerodynamics | All Rights Reserved - Version 1.1\n",

    justify="left",  # Ensure text remains left-justified
    bootstyle="primary"  # Ensures text blends into the frame
)
footer_label3.grid(row=0, column=0, columnspan=5, padx=10, pady=10, sticky="w")

import sys


class RedirectText(object):
    def __init__(self, text_widget):
        self.output = text_widget

    def write(self, string):
        self.output.configure(state='normal')  # Enable editing
        self.output.insert(tk.END, string)  # Insert text
        self.output.configure(state='disabled')  # Disable editing
        self.scroll_animation()  # Trigger the scroll animation

    def flush(self):
        pass  # Needed for compatibility with sys.stdout

    def scroll_animation(self):
        """Scroll to bottom, then up, then back down."""
        self.output.after(100, lambda: self.output.yview_moveto(1.0))  # Scroll to bottom
        self.output.after(500, lambda: self.output.yview_moveto(0.0))  # Scroll to top
        self.output.after(1000, lambda: self.output.yview_moveto(1.0))  # Scroll back to bottom


# Main GUI setup

# Default frame style
default_frame = ttk.Frame(root, padding=10, bootstyle="PRIMARY")
default_frame.grid(row=4, column=4, padx=10, pady=10, sticky="ew")

# Footer frame where output will be displayed
footer_frame = ttk.Frame(root, padding=5, bootstyle="PRIMARY")  # Another styled frame
footer_frame.grid(row=4, column=4, padx=10, pady=10, sticky="ew")

# Scrollbar
scrollbar = ttk.Scrollbar(footer_frame)
scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

# Text widget for displaying output
output_text = tk.Text(footer_frame, wrap='word', height=11, width=1, state='disabled', yscrollcommand=scrollbar.set)
output_text.pack(fill='both', expand=True)

scrollbar.config(command=output_text.yview)

# Redirect stdout and stderr
sys.stdout = RedirectText(output_text)
sys.stderr = RedirectText(output_text)

root.mainloop()
