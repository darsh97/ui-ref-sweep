import sys
import pandas as pd
import os
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QPushButton, QTableWidget, QTableWidgetItem, \
    QFileDialog, QHBoxLayout, QLabel
from PyQt5.QtGui import QColor, QPixmap, QFont
from PyQt5.QtCore import Qt

SAVE_FILE = "table_data.csv"
DEFAULT_ENCODING = "utf-8"
DEFAULT_SEPARATOR = ","
LOGO_PATH = "1-0.png"  # Path to the uploaded logo

class TableViewer(QWidget):
    def __init__(self, csv_file=None):
        super().__init__()
        self.setWindowTitle("CSV Table Viewer")
        self.setGeometry(100, 100, 800, 600)

        self.layout = QVBoxLayout()

        # Add logo and title
        self.header_layout = QHBoxLayout()
        self.logo_label = QLabel(self)
        pixmap = QPixmap(LOGO_PATH)
        if not pixmap.isNull():
            self.logo_label.setPixmap(pixmap)
        # Resize the pixmap to a specific width and height (e.g., 100x100)
        scaled_pixmap = pixmap.scaled(300, 100, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        # Set the scaled pixmap to the label
        self.logo_label.setPixmap(scaled_pixmap)
        self.logo_label.setAlignment(Qt.AlignLeft)


        self.title_label = QLabel("Aerodynamic Wind Tunnel Data Summary")
        self.title_label.setAlignment(Qt.AlignCenter)
        font = QFont()
        font.setBold(True)
        font.setPointSize(40)
        self.title_label.setFont(font)

        self.header_layout.addWidget(self.logo_label)
        self.header_layout.addWidget(self.title_label)
        self.layout.addLayout(self.header_layout)

        self.button_layout = QHBoxLayout()

        self.import_button = QPushButton("Import Data")
        self.import_button.clicked.connect(self.load_csv)
        self.button_layout.addWidget(self.import_button)
        self.runs=1

        self.clear_button = QPushButton("Clear Data")
        self.clear_button.clicked.connect(self.clear_table)
        self.button_layout.addWidget(self.clear_button)

        self.export_button = QPushButton("Export Data")
        self.export_button.clicked.connect(self.export_table)
        self.button_layout.addWidget(self.export_button)

        # Set button font size and height
        button_font = QFont()
        button_font.setPointSize(15)  # Increase font size

        self.import_button.setFont(button_font)
        self.import_button.setMinimumHeight(30)  # Set button height
        self.import_button.setMinimumWidth(200)  # Set button height
        self.clear_button.setFont(button_font)
        self.clear_button.setMinimumHeight(30)
        self.clear_button.setMinimumWidth(200)  # Set button height
        self.export_button.setFont(button_font)
        self.export_button.setMinimumHeight(30)
        self.export_button.setMinimumWidth(200)  # Set button height

        self.button_layout.addStretch()
        self.layout.addLayout(self.button_layout)

        self.table = QTableWidget()

        # Set header color styling
        self.table.horizontalHeader().setStyleSheet(
            "QHeaderView::section { background-color: lightgrey; color: black; font-weight: bold; font-size: 14pt; }"
        )

        self.layout.addWidget(self.table)
        self.setLayout(self.layout)

        self.file_data = []
        self.column_headers = None
        self.input_file_format = DEFAULT_SEPARATOR
        self.base_df = None
        self.updating_table = False
        self.edited_data = {}

        self.table.itemChanged.connect(self.handle_item_edit)
        self.load_previous_data()

        # Load CSV automatically if provided
        if csv_file and os.path.exists(csv_file):
            self.load_csv(csv_file)



    def load_previous_data(self):
        if os.path.exists(SAVE_FILE):
            try:
                df = pd.read_csv(SAVE_FILE, encoding=DEFAULT_ENCODING, sep=DEFAULT_SEPARATOR)
                if not df.empty:
                    self.file_data = [df]
                    self.column_headers = df.columns.tolist()
                    self.base_df = df.copy()
                    self.display_data()
            except (UnicodeDecodeError, pd.errors.EmptyDataError):
                return

    def load_csv(self, file_path=None):

        options = QFileDialog.Options()

        if file_path == None:
            file_path, _ = QFileDialog.getOpenFileName(self, "Import CSV File", "", "CSV Files (*.csv);;All Files (*)",
                                                   options=options)

        if not file_path:
            file_path, _ = QFileDialog.getOpenFileName(self, "Import CSV File", "", "CSV Files (*.csv);;All Files (*)",
                                                   options=options)
            if not file_path:
                return


        try:
            with open(file_path, 'r', encoding=DEFAULT_ENCODING) as f:
                first_line = f.readline()
                self.input_file_format = ',' if ',' in first_line else '\t'
            df = pd.read_csv(file_path, encoding=DEFAULT_ENCODING, sep=self.input_file_format)
        except UnicodeDecodeError:
            df = pd.read_csv(file_path, encoding='ISO-8859-1', sep=self.input_file_format)

        if self.base_df is None:
            self.base_df = df.copy()
        else:
            gap = pd.DataFrame([[''] * df.shape[1]], columns=df.columns)
            self.file_data.append(gap)

            for col in ['CD', 'CLF', 'CLR', 'CLLF', 'CLRF', 'CLLR', 'CLRR', 'CL', 'CSF', 'CSR', 'CS', 'Qcorr']:
                if col in df.columns and col in self.base_df.columns:
                    df[f'Del-{col}'] = (pd.to_numeric(df[col], errors='coerce') -
                                        pd.to_numeric(self.base_df[col], errors='coerce')).round(4)

        self.file_data.append(df)
        self.column_headers = df.columns.tolist()

        for col in ['Del-CD', 'Del-CLF', 'Del-CLR', 'Del-CLLF', 'Del-CLRF', 'Del-CLLR', 'Del-CLRR', 'Del-CL', 'Del-CSF',
                    'Del-CSR', 'Del-CS', 'Del-Qcorr']:
            if col in df.columns and col not in self.column_headers:
                self.column_headers.append(col)

        self.runs=self.runs+1

        self.display_data()
        self.save_table()


    def load_table_from_dict(self, filtered_data):
        """
        Populates the QTableWidget with data from a dictionary.
        """
        # Validation for filtered_data
        if not isinstance(filtered_data, dict):
            raise ValueError("Input data must be a dictionary.")

        # Extract headers and row data
        column_headers = list(filtered_data.keys())
        row_data = zip(*filtered_data.values())  # Transpose dictionary values to rows

        # Configure the table
        self.table.setRowCount(0)
        self.table.setColumnCount(0)

        self.table.setColumnCount(len(column_headers))
        self.table.setHorizontalHeaderLabels(column_headers)

        self.table.setRowCount(len(filtered_data[next(iter(filtered_data))]))
        for row_idx, row in enumerate(row_data):
            for col_idx, value in enumerate(row):
                self.table.setItem(row_idx, col_idx, QTableWidgetItem(str(value)))

    def display_data(self):
        if not self.file_data:
            return

        self.updating_table = True
        combined_df = pd.concat(self.file_data, ignore_index=True)
        self.table.blockSignals(True)

        self.table.setRowCount(combined_df.shape[0])
        self.table.setColumnCount(combined_df.shape[1])

        if self.column_headers:
            self.table.setHorizontalHeaderLabels(self.column_headers)

        # Set header font to size 14
        header_font = QFont()
        header_font.setPointSize(14)
        header_font.setBold(True)  # Make it bold for better visibility

        self.table.horizontalHeader().setFont(header_font)

        # Define font size 14 for table items
        cell_font = QFont()
        cell_font.setPointSize(12)

        for row in range(combined_df.shape[0]):
            for col in range(combined_df.shape[1]):
                key = (row, col)
                item_value = self.edited_data.get(key, combined_df.iat[row, col] if pd.notna(
                    combined_df.iat[row, col]) else "")
                if isinstance(item_value, float):
                    item_value = round(item_value, 4)
                item = QTableWidgetItem(str(item_value))

                # Set font size for table items
                item.setFont(cell_font)

                # Apply color formatting
                column_name = self.column_headers[col] if col < len(self.column_headers) else ""
                if column_name in ['Del-CD', 'Del-CLF', 'Del-CLR', 'Del-CLLF', 'Del-CLRF', 'Del-CLLR', 'Del-CLRR',
                                   'Del-CL', 'Del-CSF', 'Del-CSR', 'Del-CS', 'Del-Qcorr', 'DelStruC', 'HBC', 'qcN/qm',
                                   'qDel/qm', 'Yaw']:
                    try:
                        val = float(item_value)
                        if column_name in ['Del-CD', 'DelStruC', 'Del-CLF', 'Del-CLR', 'Del-CLLF', 'Del-CLRF',
                                           'Del-CLLR', 'Del-CLRR', 'Del-CL']:
                            item.setBackground(
                                QColor(255, 99, 71) if val > 0 else QColor(0, 255, 0) if val < 0 else QColor(82, 136,
                                                                                                             219))
                        elif column_name in ['Del-CSF', 'Del-CSR', 'Del-CS', 'Del-Qcorr', 'HBC']:
                            item.setBackground(
                                QColor(255, 99, 71) if val < 0 else QColor(0, 255, 0) if val > 0 else QColor(82, 136,
                                                                                                             219))
                        elif column_name == 'qcN/qm':
                            item.setBackground(
                                QColor(255, 99, 71) if val < 0.998 or val > 1.02 else QColor(144, 238, 144))
                        elif column_name == 'Yaw':
                            item.setBackground(
                                QColor(255, 99, 71) if val > 0 else QColor(255, 99, 71) if val < 0 else QColor(82, 136,
                                                                                                               219))
                    except ValueError:
                        pass

                self.table.setItem(row, col, item)

        self.table.blockSignals(False)
        self.updating_table = False

    def handle_item_edit(self, item):
        if self.updating_table:
            return
        row, col = item.row(), item.column()
        self.edited_data[(row, col)] = item.text()

    def export_table(self):
        options = QFileDialog.Options()
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Export Table as CSV", "", "CSV Files (*.csv);;All Files (*)", options=options
        )

        if not file_path:
            return

        self.save_table(file_path)

    def save_table(self, file_path=SAVE_FILE):
        df = pd.DataFrame([[self.table.item(row, col).text() if self.table.item(row, col) else "" for col in range(self.table.columnCount())] for row in range(self.table.rowCount())], columns=self.column_headers)
        df.to_csv(file_path, index=False, encoding=DEFAULT_ENCODING, sep=self.input_file_format)

    def clear_table(self):
        self.file_data.clear()
        self.edited_data.clear()
        self.base_df = None
        self.table.clear()
        if os.path.exists(SAVE_FILE):
            os.remove(SAVE_FILE)



if __name__ == "__main__":

    app = QApplication(sys.argv)
    viewer = TableViewer()
    viewer.show()
    sys.exit(app.exec_())
