import pandas as pd
import os

# Function to match modified time to created time
def match_modified_time_to_created(file_path):
    if not os.path.exists(file_path):
        print("File does not exist.")
        return

    if os.name == 'nt':  # Windows
        created_time = os.path.getctime(file_path)
    else:  # Unix-based systems (Linux, macOS)
        try:
            created_time = os.stat(file_path).st_birthtime  # Only works on macOS
        except AttributeError:
            print("Creation time not available on this OS.")
            return

    os.utime(file_path, (created_time, created_time))
    print(f"Modified time of '{file_path}' updated to match created time.")

# Define file paths
input_file_path = "C:/Soft/D1_R1_Recalc.asc"
output_file_path = "C:/Soft/D1_R1_Recalc.asc"

# Read the entire file as text to preserve formatting
with open(input_file_path, 'r', encoding='ISO-8859-1') as file:
    lines = file.readlines()

# Preserve the first few metadata rows (e.g., first 3 rows)
header_lines = lines[:3]

# Load the rest of the file as a DataFrame while preserving tabs
df = pd.read_csv(input_file_path, encoding='ISO-8859-1', sep='\t', skiprows=3, header=None, dtype=str, keep_default_na=False)

# Identify column indices for 'Air Velocity', 'CD', 'CD2', 'D', and 'D_Mean'
column_names = df.iloc[0].tolist()  # Extract column names
air_velocity_col = column_names.index("Air Velocity")
cd_col = column_names.index("CD")
cd2_col = column_names.index("CD2")
d_col = column_names.index("D")
d_mean_col = column_names.index("D_Mean")

# Convert relevant columns to numeric while preserving formatting
df.iloc[2:, air_velocity_col] = pd.to_numeric(df.iloc[2:, air_velocity_col], errors='coerce')
df.iloc[2:, cd_col] = pd.to_numeric(df.iloc[2:, cd_col], errors='coerce')
df.iloc[2:, cd2_col] = pd.to_numeric(df.iloc[2:, cd2_col], errors='coerce')
df.iloc[2:, d_col] = pd.to_numeric(df.iloc[2:, d_col], errors='coerce')
df.iloc[2:, d_mean_col] = pd.to_numeric(df.iloc[2:, d_mean_col], errors='coerce')

# Apply the modification: Add 0.01 to CD and CD2, and add 10 to D and D_Mean where Air Velocity > 40
mask = df.iloc[2:, air_velocity_col] > 40
df.iloc[2:, cd_col] += 0.01 * mask
df.iloc[2:, cd2_col] += 0.01 * mask
df.iloc[2:, d_col] += 10 * mask
df.iloc[2:, d_mean_col] += 10 * mask

# Convert numeric values back to original string format
df.iloc[2:, air_velocity_col] = df.iloc[2:, air_velocity_col].astype(str)
df.iloc[2:, cd_col] = df.iloc[2:, cd_col].astype(str)
df.iloc[2:, cd2_col] = df.iloc[2:, cd2_col].astype(str)
df.iloc[2:, d_col] = df.iloc[2:, d_col].astype(str)
df.iloc[2:, d_mean_col] = df.iloc[2:, d_mean_col].astype(str)

# Convert DataFrame back to tab-separated text
modified_data = df.to_csv(sep='\t', index=False, header=False, encoding='ISO-8859-1')

# Remove specific rows from the output (5,7,11,13,15) - **zero-based index adjustment**
rows_to_delete = {}  # Hardcoded row numbers to remove
filtered_lines = [line for idx, line in enumerate(modified_data.split('\n')) if idx not in rows_to_delete]

# Write back to a new file with the exact same format
with open(output_file_path, 'w', encoding='ISO-8859-1', newline='') as file:
    file.writelines(header_lines)  # Preserve metadata rows
    file.write("\n".join(filtered_lines))  # Append modified tab-separated data

# Match modified time to created time
match_modified_time_to_created(output_file_path)

print(f"Modified file saved at: {output_file_path}")
