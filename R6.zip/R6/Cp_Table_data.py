# -*- coding: utf-8 -*-
"""
Created on Tue Jan 21 09:35:20 2025

@author: AdnanShahriar(Contra
"""

import numpy as np
import matplotlib.pyplot as plt
from Supporting_files import central_difference_derivative
from Supporting_files import linear_interpolation
from Supporting_files import quadratic_interpolation

def cp_table_data():
    
    cp_table = np.array([
        [0.0762, 0.0035, -0.0005],
        [0.3048, 0.0057, 0.0024],
        [0.9144, 0.0065, 0.0015],
        [1.2192, 0.0044, 0.001],
        [1.524, 0.0042, 0.0018],
        [1.8288, 0.0035, 0.0008],
        [2.4384, 0.0017, -0.0024],
        [3.048, 0.0009, -0.0019],
        [4.064, 0.001, -0.0024],
        [4.8768, 0.0009, -0.0018],
        [5.334, -0.0002, 0],
        [5.7912, 0.0001, -0.0011],
        [6.096, -0.0011, -0.0007],
        [6.4008, -0.0011, 0.0004],
        [6.858, -0.0012, 0.0006],
        [7.1628, -0.0017, 0.0011],
        [7.4676, -0.0019, 0.0026],
        [7.7597, -0.0028, 0.0038],
        [8.128, -0.0056, 0.0075],
        [8.4582, -0.0067, 0.0137],
        [8.6868, -0.0061, 0.0179],
        [8.8392, -0.0056, 0.0206],
        [8.9916, -0.0053, 0.0242],
        [9.144, -0.0041, 0.0309],
        [9.2964, -0.0022, 0.0358],
        [9.4488, -0.0003, 0.0409],
        [10.0584, 0.0018, 0.0715]
    ])
        
    return cp_table


def cp_table_derivetive():

    A=cp_table_data()
    x=A[:,0]
    cp1=A[:,1]
    cp2=A[:,2]
    
    dcp1_dx = central_difference_derivative(x, cp1)
    dcp2_dx = central_difference_derivative(x, cp2)
    
    cp_der_table = np.column_stack((x, dcp1_dx, dcp2_dx))
    
    return cp_der_table




def get_CP1(target_x):
    A=cp_table_data()
    x=A[:,0]
    cp1=A[:,1]
    cp2=A[:,2]
    
    return linear_interpolation(x, cp1, target_x)


def get_CP2(target_x):
    A=cp_table_data()
    x=A[:,0]
    cp1=A[:,1]
    cp2=A[:,2]
    
    return linear_interpolation(x, cp2, target_x)


def get_dx_CP1(target_x):
    A=cp_table_derivetive()
    x=A[:,0]
    dcp1=A[:,1]
    dcp2=A[:,2]
    
    return linear_interpolation(x, dcp1, target_x)


def get_dx_CP2(target_x):
    A=cp_table_derivetive()
    x=A[:,0]
    dcp1=A[:,1]
    dcp2=A[:,2]
    
    return linear_interpolation(x, dcp2, target_x)







