# import math
import numpy as np
# import pandas as pd
# import matplotlib.pyplot as plt

from Cp_Table_data import cp_table_data

print("Horizontal Buoyancy Correction - Wind Shear Wind Tunnel: Jan-02-2025")

"""
The code provided calculates the horizontal buoyancy correction using specific parameters and a buoyancy table. 
The correction is based on the pressure differences at two points (front and rear buoyancy points)
along the length of the object. Difference in - Front and back push force on the object.
The Glauert factor is used to adjust the correction

Calculates the classical horizontal buoyancy correction according to SAE 2005-01-0867 Equations (4)-(6)
x   - numpy array of grid for the empty-tunnel Cp measurements (must be same fo r both gradients)
CDm = measured CD (CL, CPM, Cp) in the tunnel's natural pressure gradient.
"""

"----------------------------------------------------------------------------------------------------------------------"

"Inputs"
#HM = 1.742  # Model Height
#LM = 5.514  # Vehicle length (body axis) in meters
#WM = 2.013  # Body width (meters)
#FA = 3.041  # Frontal area (square meters)
#SA = 6.651  # Side area (square meters)
#volume = 10.140  # Vehicle Volume
#WB = 3.449  # Wheel Base
#FOH = 0.9   # Vehicle front overhang (body axis) in meters
#XM = 4.067


"----------------------------------------------------------------------------------------------------------------------"

def horizontal_buyancy_execution(HM, LM, FA, SA, volume, WB, FOH, XM):

    Pi = np.pi  # Value of Pi

    "Calculate the position of the front and rear bumper"
    x_front_bmpr = XM - FOH - (WB/2)
    x_rear_bmpr = x_front_bmpr + LM

    "Import cp table"
    # df = pd.read_csv('C:/Users/VasanthaJayasankaran/Desktop/Code/correction_v2/HBC1.csv')
    # X = df['X'].values  # Extract X and Cp1 columns
    # Cp1 = df['Cp1'].values  # Extract X and Cp1 columns
    # cp_front = np.interp(x_front_bmpr, df['X'], df['Cp1'])  # Get Cp at the front bumper
    # cp_rear = np.interp(x_rear_bmpr, df['X'], df['Cp1'])  # Get Cp at the rear bumper
    
    
    cp_table=cp_table_data()
    
    X=cp_table[:, 0]
    Cp1=cp_table[:, 1]
    
    "Get the Cp values at the front bumper and rear bumper"
    # Calculate the absolute difference
    Diff = np.abs(X - x_front_bmpr)
    # Find the index and value of the minimum
    position = np.argmin(Diff)  # Index of the minimum value
    min_value = Diff[position]  # Minimum value itself
    cp_front = Cp1[position]
    
    # Calculate the absolute difference
    Diff = np.abs(X - x_rear_bmpr)
    # Find the index and value of the minimum
    position = np.argmin(Diff)  # Index of the minimum value
    min_value = Diff[position]  # Minimum value itself
    cp_rear = Cp1[position]    
    
    


    "Calculate the Glauert factor, which is used in the drag correction calculation"
    t = 2 * np.sqrt(2 * (FA / Pi))  # Calculate t using the frontal area of the car
    glauert = 1 + 0.4 * (t / LM)

    "Calculate the horizontal buoyancy correction"
    "dCDHB = glauert * Volume to Frontal Area Ratio * Pressure Difference per Unit Length"
    dCDHB = glauert * (volume / FA) * ((cp_rear - cp_front) / (x_rear_bmpr - x_front_bmpr))

    """The horizontal buoyancy correction (dCDHB) represents the additional horizontal force component
    due to the difference in pressure distribution along the length of the object."""
    print(f"Horizontal Buoyancy:", dCDHB)
    print(f"CP_Front:", cp_front)
    print(f"CP_Rear:", cp_rear)
    print(f"X Front Bumper:", x_front_bmpr)
    print(f"X Rear Bumper:", x_rear_bmpr)
    
    return dCDHB, x_front_bmpr, x_rear_bmpr, cp_front, cp_rear, glauert

    "----------------------------------------------------------------------------------------------------------------------"


# horizontal_buyancy_execution(HM, LM, FA, SA, volume, WB, FOH, XM)

"""Discussion:
The Glauert factor is used to account for certain geometric effects that influence the drag coefficient.
While the Glauert factor is more commonly associated with compressibility corrections in aerodynamics, 
in this specific application, it is used to adjust the drag coefficient based on the physical dimensions 
and shape of the model.The horizontal buoyancy correction accounts for the pressure differences between the
front and rear of the model.The Glauert factor in this context modifies the correction term based on the geometric 
properties of the model.This factor increases the correction based on the aspect ratio of the model.It accounts for 
the fact that longer and slimmer models (with higher LM) have different pressure distribution characteristics 
compared to shorter and bulkier ones. The coefficient G serves as a correction factor that adjusts the 
horizontal buoyancy correction based on the geometry of the object, particularly its length and frontal area. """