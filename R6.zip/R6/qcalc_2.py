# -*- coding: utf-8 -*-
"""
Created on Wed Feb  5 11:34:27 2025

@author: AdnanShahriar(Contra
"""

import math
import numpy as np
import matplotlib.pyplot as plt
# import pandas as pd
import sys

print("Wind Tunnel = Corrections - Wind Shear Wind Tunnel")


"""---------------------------------------------------------------------------------------------------------------------
Merker-Weidemann-Cooper Correction Method:
A)  Inputs:
1.  Vehicle Geometry Input
2.  Location Measurement NEP/CIP
3.  Inputs for D1_Recalc

--------------------------------------------------------------------------------------------------------------------"""
"----------------------------------------------------------------------------------------------------------------------"

"B) Solving Xs - singularity location for body of revolution representing the vehicle (measured +x from NEP)"

"----------------------------------------------------------------------------------------------------------------------"

"""
Calclautes dynamic pressure fully corrected for blockage according to SAE 2006-01-0568.
This function is similar to q_implicit (next function down the list) except tunnel
geometry parameters are obtained from the subroutine TunnelGeom instead of being passed in
Note that the method argument can be either 0 or 1 since we are presumably arriving at the same corrected result."""

def qc_implicit_tun(tunnel, method, qN, qP, yaw, CDU, CSU, LM, WM, FA, SA, XM, WB, FOH, near_wake, veh_type, Plotting, Correction_calculation):
    
    [H_Noz, W_Noz, H_Col, W_Col, L_Col, FlapAng, XL] = tunnel_geom(tunnel)  # Get tunnel geometry


    # Vehicle parameters
    XN = np.zeros(len(yaw))
    XC = np.zeros(len(yaw))
    x = np.zeros(len(yaw))
    t = np.zeros(len(yaw))
    CDU_wa = np.zeros(len(yaw))
    CC = np.zeros(len(yaw))
    RC = np.zeros(len(yaw))
    S = np.zeros(len(yaw))
    qc_explicit_N = np.zeros(len(yaw)) 
    qc_explicit_P = np.zeros(len(yaw))

    # Correction parameters
    results = np.zeros(len(yaw))
    Xs = np.zeros(len(yaw))
    epsN = np.zeros(len(yaw))
    epsS = np.zeros(len(yaw))
    epsP = np.zeros(len(yaw))
    epsC = np.zeros(len(yaw))
    
    if Plotting == 1:
        # Initialize flexible lists instead of fixed-sized arrays
        XSS_T  = np.zeros((len(yaw), 64))
        q00N_T = np.zeros((len(yaw), 64)) 
        q00P_T = np.zeros((len(yaw), 64)) 
    else:
        XSS_T = None
        q00N_T = None
        q00P_T = None


    for i in range(len(yaw)):
        
        
        [CN, RN, x[i], S[i], CC[i], RC[i], VehVolDu, L_Proj, FA_Proj_Du, XC[i], t[i], CDU_wa[i], XN[i]]=veicle_tunnel_parameters(H_Noz, W_Noz, H_Col, W_Col, L_Col, FlapAng, XL, XM, FA, LM, WM, FA, SA, WB, FOH, float(yaw[i]), float(CDU[i]), float(CSU[i]),veh_type)
        #                                                                                                                       (H_Noz, W_Noz, H_Col, W_Col, L_Col, FlapAng, XL, XM, FA, LM, WM, SM, Sside, WB, FOH, yaw, CDU, CSU, veh_type):
        Xs[i] = Xs_Converged(qN[i], qP[i], CN, RN, x[i], S[i])
                
        
        # 0 indicates windshear
        if Correction_calculation == 0: 
            results[i], qc_explicit_N[i], qc_explicit_P[i], epsN[i], epsS[i], epsP[i], epsC[i], _, _ = qc_explicit(qN[i], qP[i], method, Xs[i],near_wake,CN, RN, x[i], S[i], CC[i], RC[i], VehVolDu, L_Proj, FA_Proj_Du, XC[i], t[i], CDU_wa[i])
            
        # 1 indicates J2881            
        elif Correction_calculation == 1:
            results[i], qc_explicit_N[i], qc_explicit_P[i], epsN[i], epsS[i], epsP[i], epsC[i], _, _ = qc_explicit_J2281(qN[i], qP[i], method, Xs[i],near_wake,CN, RN, x[i], S[i], CC[i], RC[i], VehVolDu, L_Proj, FA_Proj_Du, XC[i], t[i], CDU_wa[i])


    if Plotting == 1:
        # plotter(qN, qP, yaw, CDU, CSU, LM, WM, SA, FA, XM, WB, FOH, Xs, veh_type, H_Noz, W_Noz, H_Col, W_Col, L_Col, FlapAng, XL, method, near_wake)

        # XSS = np.arange(Xs[i] - Xs[i] - Xs[i] / 5, Xs[i] + Xs[i] * 5 + Xs[i] / 5, Xs[i] / 10)
        
        
        XSS = np.linspace(
            Xs[i] - Xs[i] - Xs[i] / 5,  # Start
            Xs[i] + Xs[i] * 5 + Xs[i] / 5,  # End
            num=64  # Restrict to exactly 64 elements
            )        
        
        # print("XSS", XSS)
        
        q00N=np.zeros(len(XSS))
        q00P=np.zeros(len(XSS))
        
        j = 0
        for X in XSS:
             _, _, _, _, _, _, _, q00N[j], q00P[j] = qc_explicit(qN[i], qP[i], method, XSS[j],near_wake,CN, RN, x[i], S[i], CC[i], RC[i], VehVolDu, L_Proj, FA_Proj_Du, XC[i], t[i], CDU_wa[i])
             
             XSS_T[i,j] = XSS[j]
             q00N_T[i,j] = q00N[j]
             q00P_T[i,j] = q00P[j]             
             
             j=j+1



    Correction_output = {
        "Xs": Xs,
        "qNc": qc_explicit_N,
        "qPc": qc_explicit_P,        
        "epsN": epsN,
        "epsS": epsS,
        "epsP": epsP,
        "epsC": epsC
    }


    Vehicle_parameter_output= {
        "A_Noz": CN/2,
        "RN": RN,
        "x": x,
        "S": S,
        "CC": CC,
        "RC": RC,
        "VehVolDu": VehVolDu,
        "L_Proj": L_Proj,
        "FA_Proj_Du":FA_Proj_Du,
        "XC": XC,
        "t": t,
        "CDU_wa": CDU_wa, 
        "XN": XN,
        }




    return results, Correction_output, Vehicle_parameter_output, XSS_T, q00N_T, q00P_T

"""
Calculates fully-corrected dynamic pressure, qc.  The units are the same as input measured dynamic pressure, qm,
as long as all other arguments having powers of length are dimensionally consistent with one another (e.g., all ft)
and the vehicle yaw and flap angles are in degrees.

    Xs - singularity location for body of revolution representing the vehicle (measured +x from NEP)
    overrideTau = -0.275 this is the value Edzard used for AVZ 1:1 SM, but it is not quite right.
"""

def qc_explicit(qN, qP, method, Xs,near_wake,CN, RN, x, S, CC, RC, VehVolDu, L_Proj, FA_Proj_Du, XC, t, CDU_wa):

    q00N = q0(qN, 0, Xs, CN, RN, x, S)
    epsN = epsilonN(Xs, S, CN, RN, x)
    epsS = epsilonS(t, VehVolDu, L_Proj, FA_Proj_Du, epsN, x, CN)

    q00P = q0(qP, 1, Xs, CN, RN, x, S)
    epsP = epsilonP(Xs, S, RN, x)

    epsC = epsilonC(CDU_wa, S, CC, FA_Proj_Du, RC, XC, near_wake)  # External

    qc_explicit_N = q00N * (1 + epsS + epsC) ** 2
    qc_explicit_P = q00N * (1 + epsS + epsC) ** 2

    if method==0:
        qc_explicit = qc_explicit_N
    else:
        qc_explicit = qc_explicit_P
        
    return qc_explicit, qc_explicit_N, qc_explicit_P, epsN, epsS, epsP, epsC, q00N, q00P


def qc_explicit_J2281(qN, qP, method, Xs,near_wake,CN, RN, x, S, CC, RC, VehVolDu, L_Proj, FA_Proj_Du, XC, t, CDU_wa):

    q00N = q0(qN, 0, Xs, CN, RN, x, S)
    epsN = epsilonN(Xs, S, CN, RN, x)
    epsS = epsilonS(t, VehVolDu, L_Proj, FA_Proj_Du, epsN, x, CN)

    q00P = q0(qP, 1, Xs, CN, RN, x, S)
    epsP = epsilonP(Xs, S, RN, x)

    epsC = epsilonC(CDU_wa, S, CC, FA_Proj_Du, RC, XC, near_wake)  # External

    qc_explicit_N = qN * (1 + epsN + epsS + epsC) ** 2
    
    qc_explicit_P = qP * (1 + epsN + epsS + epsC) ** 2    


    if method==0:
        qc_explicit = qc_explicit_N
    else:
        qc_explicit = qc_explicit_P
        
        
    
    

    return qc_explicit, qc_explicit_N, qc_explicit_P, epsN, epsS, epsP, epsC, q00N, q00P



""""
Calculates a dynamic pressure, q0, corrected (only) for nozzle interference.  The units of q0
are the same as the units of qm, provided that all other arguments to this function are
within themselves dimensionally consistent.  (All other args have units of length or length^2
except yaw angle, which is in degrees"""


def q0(qm, method, Xs, CN, RN, x, S):

    if method == 0:
        epsilon = epsilonN(Xs, S, CN, RN, x)
    else:
        epsilon = epsilonP(Xs, S, RN, x)

    return qm * (1 + epsilon) ** 2

"""
Finds the location of the singularity for the body of revolution representing the vehicle (measured from NEP)
such that dynamic pressures measured by the nozzle and plenum methods match one another when corrected (only)
for nozzle blockage.
The Newton-Raphson method is used to solve Equation a4 in SAE 2006-01-0568 for Xs.

Discussion:
Initially, we used an initial guess of 10% of body length ahead of the front bumper.  For a very low
nozzle blockage situation, this failed to converge.  So we changed the initial guess to 100 mm downstream
of the nozzle exit plane.
"""


def Xs_Converged(qN, qP, CN, RN, x, S):
    tolerance = 0.0001  # Convergence tolerance
    incr = 0.001  # Delta Xs to estimate the derivative
    Xs = 0.01  # Initial guess for extremely low blockage

    q0N= q0(qN, 0, Xs, CN, RN, x, S)

    q0P = q0(qP, 1, Xs, CN, RN, x, S)

    Fn = 1 - (q0N / q0P)  # Solving for Function f(Xs)

    dXs = Xs * (1 + incr)
    dq0N = q0(qN, 0, dXs, CN, RN, x, S)

    dq0P = q0(qP, 1, dXs, CN, RN, x, S)
    dFn = ((q0N / q0P) - (dq0N / dq0P)) / (Xs * incr)  # Derivative Respect to Xs

    i = 1
    while abs(Fn) >= tolerance and i < 100:
        Xs = Xs - Fn / dFn
        q0N = q0(qN, 0, Xs, CN, RN, x, S)
        q0P = q0(qP, 1, Xs, CN, RN, x, S)

        dXs = Xs * (1 + incr)
        dq0N = q0(qN, 0, dXs, CN, RN, x, S)
        dq0P = q0(qP, 1, dXs, CN, RN, x, S)
        Fn = 1 - (q0N / q0P)

        dFn = ((q0N / q0P) - (dq0N / dq0P)) / (Xs * incr)
        i += 1

    return Xs


"""---------------------------------------------------------------------------------------------------------------------

C)   Wind Tunnel Geometry Calculation

1.  Wind Tunnel Geometry Input
2.  Nozzle Area & Equivalent Radius
3.  Collector Area & Equivalent Radius
4.  Biot-Savart Coefficient for Nozzle
5.  Wind - Axis Drag Coefficient
6.  Blockage Calculation - Epsilon

---------------------------------------------------------------------------------------------------------------------"""
"""
C1.  Wind Tunnel Geometry Input

Parameters: Retrieve the geometry data for a specific wind tunnel.
- tunnel (str): The name of the tunnel ('WT8', 'WSI', or 'AAWT').

Returns:
- tuple: Contains H_Noz, W_Noz, H_Col, W_Col, L_Col, FlapAng, XL.
"""


def tunnel_geom(tunnel):
    if tunnel == "WT8":
        # WT8 information in SI units
        H_Noz = 11 * 0.3048  # Nozzle Height
        W_Noz = 18.25 * 0.3048  # Nozzle Width
        H_Col = (14 + 10.75 / 12) * 0.3048  # Collector Height at entrance to high-speed diffuser
        W_Col = (22 + (8 + 7 / 8) / 12) * 0.3048  # Collector width at entrance to high-speed diffuser
        L_Col = (9 + 7 / 12) * 0.3048  # Collector Length
        FlapAng = 10  # Flap angle
        XL = 48 * 0.3048  # Test Section Length - Nozzle exit plane to collector inlet plane
        # XM = 15 * 0.3048  # XM is not returned as it might change

    elif tunnel == "WSI":
        # WSI information in SI units
        H_Noz = 10 * 0.3048  # Nozzle Height
        W_Noz = 18 * 0.3048  # Nozzle Width
        H_Col = (14 + 10 / 12) * 0.3048  # Collector Height at entrance to high-speed diffuser
        W_Col = (22 + 8 / 12) * 0.3048  # Collector width at entrance to high-speed diffuser
        L_Col = 11 * 0.3048  # Collector Length
        FlapAng = (14.3 + 14.4 + 14) / 3  # Flap angle
        XL = 47.5 * 0.3048  # Test Section Length - Nozzle exit plane to collector inlet plane

    elif tunnel == "AAWT":
        # AAWT information in SI units
        H_Noz = (13.25 - 0.25) * 0.3048  # Nozzle Height
        W_Noz = (22 + 8 / 12) * 0.3048  # Nozzle Width
        H_Col = (17 + 10 / 12) * 0.3048  # Collector Height at entrance to high-speed diffuser
        W_Col = (28 + 6.75 / 12) * 0.3048  # Collector width at entrance to high-speed diffuser
        L_Col = (12 + 9 / 12) * 0.3048  # Collector Length
        FlapAng = 13.5  # This is an assumed average
        XL = (47 + 3 / 12) * 0.3048  # Test Section Length - Nozzle exit plane to collector inlet plane
        # XM = 19 * 0.3048  # XM is not returned as it might change

    else:
        # If tunnel type is not recognized, default to WT8 or raise an error
        print(f"There is no airline data for the tunnel '{tunnel}'. WT8 data is being used.")

    return (H_Noz, W_Noz, H_Col, W_Col, L_Col, FlapAng, XL)


def get_tunnel_geom(tunnel):
    return list(tunnel_geom(tunnel))


"""
    Get tunnel geometry parameters for diagnostic purposes.

    Parameters:
    - tunnel (str): The name of the tunnel.

    Returns:
    - list: List containing tunnel geometry parameters.
    """
"----------------------------------------------------------------------------------------------------------------------"

def veicle_tunnel_parameters(H_Noz, W_Noz, H_Col, W_Col, L_Col, FlapAng, XL, XM, FA, LM, WM, SM, Sside, WB, FOH, yaw, CDU, CSU, veh_type):

    CN = 2 * A_Noz(H_Noz, W_Noz)
    RN = R_Noz(CN)

    # This is wind-axis distance of the nozzle exit plane to the front bumper.
    # The last arg should be zero for best calc, that's why it is hard-coded.
    XN = FrtBmpr(LM, XM, WB, FOH, yaw, 0)  # External

    x = BiotNozzle(RN, XN)  # External

    S = 2 * SM

    CC = 2 * A_Col(H_Col, W_Col, L_Col, FlapAng)  # External

    RC = R_Col(CC)  # External

    VehVolDu = 2 * VehVol(veh_type, LM, FA)  # External

    L_Proj = L_Projected(LM, WM, yaw)  # External

    FA_Proj_Du = 2 * FA_Projected(S / 2, Sside, yaw)  # External

    # This is wind-axis distance of the rear bumper to the collector entrance plane.
    # The last arg should be zero for best calc, that's why it is hard-coded.
    XC = RearBmpr(XL, LM, XM, WB, FOH, yaw, 0)  # External

    t = tau(H_Noz, W_Noz, 0)  # External

    CDU_wa = CD_Wind_Axis(CDU, CSU, yaw)  # External

    return CN, RN, x, S, CC, RC, VehVolDu, L_Proj, FA_Proj_Du, XC, t, CDU_wa, XN


"----------------------------------------------------------------------------------------------------------------------"
"""
C2.  Nozzle Area & Equivalent Radius

Nozzle Area:
Calculates the nozzle area (not duplex nozzle area).
    H_Noz - h: Nozzle height
    W_Noz - W: Nozzle width
"""


def A_Noz(h, W):
    return h * W


"""
Duplex Nozzle Radius:
Calculates the equivalent duplex nozzle radius given the duplex nozzle area.
    A_NozDu: Duplex nozzle area
"""


def R_Noz(A_NozDu):
    return math.sqrt(A_NozDu / math.pi)


def VehVol(veh_type, LM, FA):
    # Calculate the initial vehicle volume
    VehVol = LM * FA

    # Adjust the volume based on the vehicle type
    if veh_type == 0:
        VehVol *= 0.75  # Sedan/Pickup
    elif veh_type == -1:
        VehVol *= 0.85  # Wagon/SUV/Crossover
    elif veh_type == -2:
        VehVol *= 0.9  # Van
    else:
        VehVol = veh_type  # Override with the provided vehicle volume

    return VehVol

"----------------------------------------------------------------------------------------------------------------------"
"""
C3.  Collector Area & Equivalent Radius

Collector Area:
Calculates the area (not duplex) of collector inlet given height, width, length, angle (in degrees) of the flaps.
The H_Col and W_Col dimensions are taken at the throat (entrance to high speed diffuser).
The top and side flaps are assumed to be at the same angle.
If H_Col is negative, then its opposite value is returned as the collector area. This can be used to estimate
collector area when dimensions are not known.

    H_Col - h: Height at the throat (entrance to high speed diffuser)
    W_Col - W: Width at the throat (entrance to high speed diffuser)
    L_Col - L: Length of the flaps
    FlapAng -  Angle: Angle of the flaps in degrees
    Returns:   Collector area or -h if h is negative
"""


def A_Col(h, W, L, Angle):
    if h > 0:
        A_Col = (h + L * math.sin(Angle * math.pi / 180)) * (W + 2 * L * math.sin(Angle * math.pi / 180))
    else:
        return -h
    return A_Col


"""
Collector Duplex Radius:
Calculates the equivalent duplex collector radius given the duplex collector area.
    A_ColDu: Duplex collector area
    Returns: Equivalent collector radius
"""


def R_Col(A_ColDu):
    
    R_Col = (A_ColDu / math.pi) ** 0.5
    
    return R_Col


"----------------------------------------------------------------------------------------------------------------------"
"""
C4. Biot-Savart Coefficient for Nozzle

BiotNozzle - Calculates a Biot-Savart coefficient for the influence of the nozzle on the front of the vehicle.
    R_Noz - RN : Equivalent nozzle radius
    XN:          Distance from NEP to front of vehicle
"""


def BiotNozzle(RN, XN):
    
    BiotNozzle = (RN / math.sqrt(RN ** 2 + XN ** 2)) ** 3
    
    return BiotNozzle


"----------------------------------------------------------------------------------------------------------------------"
"""
C5.  Projected Length,Projected Frontal Area, Wind Axis Distance - Half Length - Front/Rear Bumper. CD - Wind Axis

Projected Vehicle Length:
Calculates projected vehicle length given body axis length and width, and yaw angle in degrees.
    LM:  Body axis length
    WM:  Body width
    yaw: Yaw angle in degrees
"""


def L_Projected(LM, WM, yaw):
    
    L_Projected = LM * math.cos(abs(yaw * math.pi / 180)) + WM * math.sin(abs(yaw * math.pi / 180))
    
    return L_Projected


"""
Projected Frontal Area:
Calculates projected frontal area given frontal area, side area, and yaw angle in degrees.
    FA:  Frontal area
    SA:  Side area
    yaw: Yaw angle in degrees
    Returns: Projected frontal area
 """

# ROH=FOH+WB


def FA_Projected(FA, SA, yaw):
    return FA * math.cos(math.radians(abs(yaw))) + SA * math.sin(math.radians(abs(yaw)))


"""
Wind-Axis Distance Vehicle Half Length:
Calculates the wind-axis half-length of the vehicle given vehicle length and yaw angle in degrees.
Does not account for difference in front overhang and rear overhang.

    LM:  Vehicle length (body axis)
    yaw: Vehicle yaw angle in degrees
"""


def LM_half(LM, yaw):
    LM_half = (LM / 2) * math.cos(abs(yaw * math.pi / 180))
    return LM_half


"""
Wind-Axis Distance to Front Bumper:
Calculates the wind-axis distance from the nozzle exit plane to the front bumper given the distance from the NEP
to the center of the wheelbase (WB/2), the front overhang (FOH), and the yaw angle in degrees.
This calculation is more refined than the LM_half function but requires the additional inputs of WB and FOH.
Method 0 for geometric using WB and FOH, non-zero for the approximation used in AVZ design documentation. 
Method 1 is not a good approximation for, e.g., pickups.

    LM:     Vehicle length (body axis)
    XM:     Distance from nozzle exit plane to center of model
    WB:     Vehicle wheelbase (body axis)
    FOH:    Vehicle front overhang (body axis)
    yaw:    Vehicle yaw angle in degrees
    method: Method of calculation -  Nozzle Method - 0 / Plenum Method 1
"""


def FrtBmpr(LM, XM, WB, FOH, yaw, method):
    if method == 0:
        FrtBmpr = XM - (FOH + WB / 2) * math.cos(math.pi * yaw / 180)
    else:
        FrtBmpr = XM - LM_half(LM, yaw)
    
    return FrtBmpr

"""
Wind-Axis Distance to Rear Bumper:
Calculates the wind-axis distance from the rear bumper to the collector inlet plane.


    XL:     Distance from the collector inlet plane to the rear end of the wind tunnel
    LM:     Vehicle length (body axis)
    XM:     Distance from nozzle exit plane to center of model
    WB:     Vehicle wheelbase (body axis)
    FOH:    Vehicle front overhang (body axis)
    yaw:    Vehicle yaw angle in degrees
    method: Method of calculation -  Nozzle Method - 0 / Plenum Method 1
"""


def RearBmpr(XL, LM, XM, WB, FOH, yaw, method):

    ROH = LM - WB - FOH  # Vehicle rear overhang (body axis) in meters

    if method == 0:
        return XL - (XM + (ROH + WB / 2) * math.cos(math.radians(yaw)))
    else:
        return XL - (XM + LM_half(LM, yaw))


"""
Wind-Axis Drag Coefficient:
Calculates the wind-axis drag coefficient from the body-axis (SAE J1594) drag and side force coefficients,and yaw angle.

    CDU: Uncorrected  Body-axis drag coefficient
    CSU: Uncorrected Side force coefficient
    yaw: Yaw angle in degrees
"""


def CD_Wind_Axis(CD, CS, yaw):
    
    CD_Wind_Axis = CD * math.cos(math.pi * yaw / 180) + CS * math.sin(math.pi * yaw / 180)
    
    return CD_Wind_Axis


"----------------------------------------------------------------------------------------------------------------------"
"""
C6.  Blockage Calculation - Epsilon

Nozzle Method QN: epsilonN
Calculates the velocity increment (blockage effect) due to nozzle interference
when q is measured with the nozzle method.

    Xs:             Singularity location for body of revolution representing the vehicle (measured +x from NEP)
    FA_Proj_Du - S: Vehicle duplex frontal area
    A_Noz - CN:     Duplex nozzle area
    R_Noz - RN :    Equivalent nozzle radius
    BiotNozzle - x: Biot-Savart Coefficient for the nozzle calculated in BiotNozzle()
    Returns:        Velocity increment
"""


def epsilonN(Xs, S, CN, RN, x):

    denom = ((Xs ** 2) + (RN ** 2)) ** 0.5
    areaParam = S / 2 / CN
    epsilonN = 1 - areaParam * (1 - Xs / denom)
    epsilonN = areaParam * (1 - Xs / denom) * x / epsilonN

    return epsilonN


"""
Plenum Method QP: epsilonP
Calculates the velocity increment (blockage effect) due to nozzle interference
when q is measured with the plenum method.
    Xs:             Singularity location for the body of revolution representing the vehicle (measured +x from NEP)
    S:              Vehicle duplex frontal area
    R_Noz - RN:     Equivalent nozzle radius
    BiotNozzle - x: Biot-Savart Coefficient for the nozzle calculated in BiotNozzle()
    Returns:        Velocity increment
"""


def epsilonP(Xs, S, RN, x):
    
    denom = (Xs ** 2 + RN ** 2) ** 1.5
    areaParam = S / 4 / 3.14159265358979
    epsilonP = 1 - areaParam * (Xs / denom)
    epsilonP = areaParam * (Xs / denom) * x / epsilonP
    
    return epsilonP


"""
TAU
Calculates the dimensionless tunnel "tau" factor for open jet blockage corrections.
This is Equation (7) from Wickern's paper, SAE 2001-01-0633.
See also SAE SP-1465 (Aerodynamic Testing of Road Vehicles in Open Jet Wind Tunnels),
Section 2, with F = (-1)^(m+n) and with the summations excluding m=n=0.

    H_Noz - h:  The actual (not duplex) nozzle height
    W_Noz - b:  The actual tunnel width
    override:   If non-zero, then its value is returned as tau
    Returns:     Calculated tau value
"""


def tau(h, b, override):
    # Set maximum values for the summations
    nMax = 60
    mMax = 60

    # Check if override is zero
    if override == 0:
        h = 2 * h  # Adjust height
        tau_value = 0  # Initialize tau to zero

        # Nested loops to perform the summations
        for n in range(-nMax, nMax + 1):
            for m in range(-mMax, mMax + 1):
                # Skip the case where n and m are both zero
                if n == 0 and m == 0:
                    continue
                else:
                    # Calculate the contribution to tau for the current values of n and m
                    tau_value += (-1) ** (n + m) * 1 / (n * n + (m * h / b) * (m * h / b)) ** 1.5

        # Final calculation of tau
        tau_value *= 0.5 * (h / b / math.pi) ** 1.5

    else:
        # If override is non-zero, use its value as tau
        tau_value = override

    return tau_value


"""
Jet Expansion: epsilonS
Calculates the velocity increment (blockage effect) due to jet expansion.

    tau:                Tunnel tau factor
    VehVolDu:           Vehicle duplex volume
    L_Proj:             Projected vehicle length
    FA_Proj_Du:         Projected frontal area of the duplex vehicle
    epsilonN - epsN :   Epsilon N value  
    BiotNozzle - x:     Biot-Savart Coefficient  
    A_Noz - CN :        Duplex nozzle area
    Returns:            Velocity increment due to jet expansion
"""


def epsilonS(tau, VehVolDu, L_Proj, FA_Proj_Du, epsN, x, CN):
    epsilonS = tau * math.sqrt(VehVolDu / L_Proj) * FA_Proj_Du * ((1 + epsN / x) / CN) ** 1.5
    return epsilonS


"""
Near Wake - Collector Blockage: epsilonC        
Calculates the velocity increment (blockage effect) due to collector blockage.
The parameter near_wake was given as 0.41 in SAE 960671 without elaboration. It is suggested in
SAE 2010-01-0760 that this term should be neglected, at least for long test sections. In this function,
it is assumed to be passed in as either 0 or 0.41, but this is not checked.

    CDU_wa - CDU_wa:    Wind-axis drag coefficient
    FA_Proj_Du - S:     Vehicle duplex frontal area
    A_Col - CC:         Collector area
    FA_Proj_Du:         Projected frontal area of the duplex vehicle
    R_Col - RC:         Equivalent collector radius
    XC (float):         Distance from End of the Vehicle to Collector Inlet Plane (CIP)
    near_wake:          Near wake parameter (typically 0 or 0.41)
    Returns:            Velocity increment due to collector blockage
"""


def epsilonC(CDU_wa, S, CC, FA_Proj_Du, RC, XC, near_wake):    
    epsilonC = ((CDU_wa / 4) * (S / CC) + near_wake * FA_Proj_Du / CC) * (RC / math.sqrt(XC ** 2 + RC ** 2)) ** 3
    return epsilonC


"----------------------------------------------------------------------------------------------------------------------"
"""Plot results"""

def plotter(qN, qP, yaw, CDU, CSU, LM, WM, SA, FA, XM, WB, FOH, Xs, veh_type, H_Noz, W_Noz, H_Col, W_Col, L_Col, FlapAng, XL, method, near_wake):

    for i in range(len(Xs)):

        XSS = np.arange(Xs[i] - Xs[i] - Xs[i] / 5, Xs[i] + Xs[i] * 5 + Xs[i] / 5, Xs[i] / 10)
        
        q00N=np.zeros(len(XSS))
        q00P=np.zeros(len(XSS))
        
        [CN, RN, x, S, CC, RC, VehVolDu, L_Proj, FA_Proj_Du, XC, t, CDU_wa]=veicle_tunnel_parameters(H_Noz, W_Noz, H_Col, W_Col, L_Col, FlapAng, XL, XM, FA, LM, WM, FA, SA, WB, FOH, yaw[i], CDU[i], CSU[i], veh_type)

        j = 0
        for X in XSS:
             _, _, _, _, _, q00N[j], q00P[j] = qc_explicit(qN[i], qP[i], method, X,near_wake,CN, RN, x, S, CC, RC, VehVolDu, L_Proj, FA_Proj_Du, XC, t, CDU_wa)
             j=j+1

        plt.figure()  # Create a new figure for each plot
        plt.plot(XSS, q00N, label="qN * (1 + epsilonN) ** 2")
        plt.plot(XSS, q00P, label="qP * (1 + epsilonP) ** 2")
        plt.xlabel("Xs")
        plt.ylabel("Error value")
        plt.legend()
        plt.title(f"epsilonN and epsilonP vs Xs (Case {i})")

    plt.show(block = False)
    plt.show()


"----------------------------------------------------------------------------------------------------------------------"
"""Dynamic Pressure Correction"""

if __name__ == "__main__":
    
    # Vehicle Geometry
    HM = 1.742  # Model Height
    LM = 5.514  # Vehicle length (body axis) in meters
    WM = 2.013  # Body width (meters)
    FA = 3.041  # Frontal area (square meters)
    SA = 6.651  # Side area (square meters)
    volume = 10.140  # Vehicle Volume
    WB = 3.449    # Wheel Base
    FOH = 0.9   # Vehicle front overhang (body axis) in meters
    ROH = LM - WB - FOH  # Vehicle rear overhang (body axis) in meters
    
    # Location Measurement NEP/CIP Values
    XM = 4.067  # Distance from NEP to ctr of model
    XN = XM - FOH - WB / 2  # Distance from NEP to front of vehicle

    # Arrays from D1 Recalc
    CDU = 0.348911  # Uncorrected Body-axis drag coefficient
    CSU = 0.0474835  # Uncorrected Side force coefficient
    
    yaw = 0.0  # Yaw angle (degrees)
    qN = 815.062  # Measured Nozzle method dynamic pressure
    qP = 872.254  # Measured Plenum method dynamic pressure
    
    # Correction Constants (From belt)
    near_wake = 0  # 0.41 in SAE 96-671, but 0 in SAE 2010-01-0760 for long test sections.
    method = 0  # Method 0 for nozzle method epsilonN, 1 for plenum method epsilonP    

    Plotter = 1

    # Ensure the function is properly defined and imported
    corrected_dynamic_pressure, Correction_output, Vehicle_parameter_output, XSS_T, q00N_T, q00P_T = qc_implicit_tun(
        "WSI", method, [qN], [qP], [yaw], [CDU], [CSU], LM, WM, FA, SA, XM, WB, FOH, near_wake, volume, Plotter
    )
    
    if Plotter == 1:
        plt.figure()  # Create a new figure for each plot
        plt.plot(XSS_T[0,:], q00N_T[0,:], label="qN * (1 + epsilonN) ** 2")
        plt.plot(XSS_T[0,:], q00P_T[0,:], label="qP * (1 + epsilonP) ** 2")
        
        # plt.scatter(Correction_output["Xs"][0],corrected_dynamic_pressure[0], color="red", marker="o", s=100, label="Xs")  # Highlight point
        
        plt.axvline(x=Correction_output["Xs"][0], color="red", linestyle="--", linewidth=2, label="Xs")
        
        plt.xlabel("Xs")
        plt.ylabel("Error value")
        plt.legend()
        plt.title("epsilonN and epsilonP vs Xs")    
        plt.show()

    
    
    

    print("Corrected dynamic pressure:", corrected_dynamic_pressure)
    
