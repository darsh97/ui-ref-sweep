# -*- coding: utf-8 -*-
"""
Created on Tue Jan 21 12:39:53 2025

@author: AdnanShahriar(Contra
"""

import numpy as np

def central_difference_derivative(x, y):
    n = len(x)
    dy_dx = np.zeros_like(y)
    
    # Central difference for inner points
    for i in range(1, n - 1):
        dy_dx[i] = (y[i + 1] - y[i - 1]) / (x[i + 1] - x[i - 1])
    
    # Forward difference for the first point
    dy_dx[0] = (y[1] - y[0]) / (x[1] - x[0])
    
    # Backward difference for the last point
    dy_dx[-1] = (y[-1] - y[-2]) / (x[-1] - x[-2])
    
    return dy_dx


def linear_interpolation(x_values, y_values, target_x):
    """
    Perform linear interpolation to find the corresponding y-value for a given x-value.
    
    Parameters:
    - x_values: Array of x-values.
    - y_values: Array of corresponding y-values (e.g., CP1 or CP2).
    - target_x: The x-value to interpolate for.
    
    Returns:
    - Interpolated y-value for the target_x.
    """
    # Ensure the target_x is within the range of x_values
    if target_x < x_values[0] or target_x > x_values[-1]:
        raise ValueError("Target x is out of bounds for the given x-values.")
    
    # Find the interval where target_x belongs
    for i in range(len(x_values) - 1):
        if x_values[i] <= target_x <= x_values[i + 1]:
            # Linear interpolation formula
            y = y_values[i] + (y_values[i + 1] - y_values[i]) * ((target_x - x_values[i]) / (x_values[i + 1] - x_values[i]))
            return y
    
    raise ValueError("Interpolation failed. Check input data.")
    
    
    
def quadratic_interpolation(x_values, y_values, target_x):
    """
    Perform quadratic interpolation to find the corresponding y-value for a given x-value.

    Parameters:
    - x_values: Array of x-values (must contain at least 3 points).
    - y_values: Array of corresponding y-values (e.g., CP1 or CP2).
    - target_x: The x-value to interpolate for.

    Returns:
    - Interpolated y-value for the target_x.
    """
    # Ensure there are at least 3 points for quadratic interpolation
    if len(x_values) < 3:
        raise ValueError("At least 3 points are required for quadratic interpolation.")

    # Find the three closest points to target_x
    diffs = np.abs(x_values - target_x)
    sorted_indices = np.argsort(diffs)[:3]  # Get indices of the three closest points
    x_subset = x_values[sorted_indices]
    y_subset = y_values[sorted_indices]

    # Sort the subset by x for consistency
    sorted_order = np.argsort(x_subset)
    x_subset = x_subset[sorted_order]
    y_subset = y_subset[sorted_order]

    # Quadratic interpolation formula
    x1, x2, x3 = x_subset
    y1, y2, y3 = y_subset
    numerator = (
        y1 * (target_x - x2) * (target_x - x3)
        + y2 * (target_x - x1) * (target_x - x3)
        + y3 * (target_x - x1) * (target_x - x2)
    )
    denominator = (
        (x1 - x2) * (x1 - x3) * (x2 - x3)
    )
    y = numerator / denominator
    return y    