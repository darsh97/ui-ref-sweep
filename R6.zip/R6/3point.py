## -*- coding: utf-8 -*-
"""
Created on Thu Feb  6 18:23:06 2025

@author: HP
"""


import dash
from dash import dcc, html
from flask import Flask
import dash_bootstrap_components as dbc
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots

# Initiate the App
server = Flask(__name__)
app = dash.Dash(__name__, server=server, external_stylesheets=[dbc.themes.SLATE, dbc.icons.BOOTSTRAP])

# Header
Logo_IMG = '/assets/image.png'
navbar = dbc.Navbar([
    html.A(
        dbc.Row([
            dbc.Col(html.Img(src=Logo_IMG, style={'height': '80px', 'width': '150px'})),
            dbc.Col(
                dbc.NavbarBrand("Scout | WindShear 3 Point Map", style={'color': 'White', 'fontSize': '100px', 'fontFamily': 'Times New Roman'})
            )
        ],
            align="center",  # Align logo and text in the center
        ),
    ),
],
    color="#2f2f2f",  # Dark background color for the navbar
    dark=True,  # Use dark text on a dark background
    className="custom-navbar",  # Custom class for additional styling if needed
)

# Import Data D1 Recalc
df = pd.read_table("D1_R1_Recalc.asc", encoding='ISO-8859-1', skiprows=[0, 1, 2, 4, 5, 6, 10], usecols=range(1, 651))
dft = pd.read_table("D2.asc", encoding='ISO-8859-1', skiprows=[0, 1, 2, 4], usecols=range(1, 444))

# Indicator titles and values
indicator_titles = ['Run', 'Velocity_mph', 'DYNPR', 'Temp', 'R_Humidity', 'RRS']
indicator_values = [
    df["Run Number"].mean(),
    df["Air Velocity"].mean(),
    df["DYNPR"].mean(),
    df["Tunnel_Air_Temp"].mean(),
    df["Relative_Humidity"].mean(),
    df["RRS Speed Feedback"].mean()
]

# Gradient colors for each card
gradient_colors = [
    'linear-gradient(to right, #FF7E5F, BLACK)',  # Card 1
    'linear-gradient(to right, #6A11CB, BLACK)',  # Card 2
    'linear-gradient(to right, #FF512F, BLACK)',  # Card 3
    'linear-gradient(to right, #00C6FF, BLACK)',  # Card 4
    'linear-gradient(to right, PURPLE, BLACK)',  # Card 5
    'linear-gradient(to right, #32CD32, BLACK)',  # Card 6
]

# Create a list of cards dynamically using a loop
cards = []
for i in range(6):
    card_content = [
        dbc.CardBody(
            [
                html.H2(indicator_titles[i], className="card-title", style={'fontSize': '20px'}),  # Set font size to 20
                html.P(f"Value: {indicator_values[i]:.2f}", className="card-text", style={'fontSize': '30px'})  # Set font size to 20
            ]
        )
    ]
    # Apply gradient color to each card
    card = dbc.Card(card_content, color='ash', inverse=True, style={'background': gradient_colors[i], 'color': 'white'})
    cards.append(dbc.Col(card, xl=2, lg=2, md=4, sm=6))  # Adjust column widths as needed
#Component Drag/Lift

Indicator_LD = make_subplots(
    rows=2,
    cols=2,
    #subplot_titles=('CD', 'CL', 'Drag LBF', 'Lift LBF'),
    specs=[[{'type': 'indicator'}, {'type': 'indicator'}],
           [{'type': 'indicator'}, {'type': 'indicator'}]]
)

# Add the indicators with customized title and number colors
Indicator_LD.add_trace(
    go.Indicator(
        mode="number",
        value=((df["CD"].mean() + df["CD2"].mean()) / 2),
        title={'text': "CD", 'font': {'size': 20, 'color': 'cyan'}},  # Title color cyan
        number={'font': {'size': 40, 'color': 'yellow'}},  # Number color yellow
        domain={'x': [0, 0.5], 'y': [0.5, 1]},  # Indicator position in the grid
    ),
    row=1,
    col=1,
)

Indicator_LD.add_trace(
    go.Indicator(
        mode="number",
        value=df["D"].mean(),
        title={'text': "Drag LBF", 'font': {'size': 20, 'color': 'orange'}},  # Title color orange
        number={'font': {'size': 40, 'color': 'lime'}},  # Number color lime
        domain={'x': [0, 0.5], 'y': [0, 0.5]},  # Indicator position in the grid
    ),
    row=2,
    col=1,
)

Indicator_LD.add_trace(
    go.Indicator(
        mode="number",
        value=df["CL"].mean(),
        title={'text': "CL", 'font': {'size': 20, 'color': 'magenta'}},  # Title color magenta
        number={'font': {'size': 40, 'color': 'lightgreen'}},  # Number color light green
        domain={'x': [0.5, 1], 'y': [0.5, 1]},  # Indicator position in the grid
    ),
    row=1,
    col=2,
)

Indicator_LD.add_trace(
    go.Indicator(
        mode="number",
        value=df["L"].mean(),
        title={'text': "Lift LBF", 'font': {'size': 20, 'color': 'red'}},  # Title color red
        number={'font': {'size': 40, 'color': 'blue'}},  # Number color blue
        domain={'x': [0.5, 1], 'y': [0, 0.5]},  # Indicator position in the grid
    ),
    row=2,
    col=2,
)

# Update the layout with Plotly dark theme and text customization
Indicator_LD.update_layout(
    template="plotly_dark",  # Dark theme for the overall layout
    plot_bgcolor='black',  # Set plot background to black
    paper_bgcolor='black',  # Set paper background to black
    font=dict(color='white'),  # Set overall font color to white
    margin=dict(l=20, r=20, t=20, b=20)  # Margin for spacing
)

# Lift-Drag Card Content
card_contentLD = [
    dbc.CardBody(
        [
            html.H2("Lift-Drag", className="card-title"),
            html.H1([dcc.Graph(figure=Indicator_LD)])
        ]
    )
]

# Create a column for the card to be displayed in Dash layout
C_LD = dbc.Col([dbc.Card(card_contentLD, color='primary', inverse=True)], xl=4, lg=4, md=4, sm=12)


#Component Transient Drag
TransientD = go.FigureWidget()
TransientD.add_scatter(name = "Cd", y = dft["CD"], x = dft.index,line=dict(color='darkblue')),
TransientD.add_scatter(name = "Cd2", y = dft["CD2"], x = dft.index,line=dict(color='red')),
TransientD.update_xaxes(range = [605,1490]),
TransientD.update_yaxes(range = [0.27,0.32])

# Apply Plotly dark theme to the flow data indicators
TransientD.update_layout(
    template="plotly_dark",  # Dark theme
    #title="Transient Drag Over Time",  # Add a title
    #xaxis_title="Index",  # Customize the x-axis label
    #yaxis_title="Cd Value",  # Customize the y-axis label
    plot_bgcolor='black',  # Set plot background color to black
    paper_bgcolor='black',  # Set paper background color to black
    font=dict(color='white'),  # Set font color to white
    autosize=True,  # Enable autosizing to fit the screen
    margin=dict(l=20, r=20, t=40, b=20)  # Adjust margins to avoid excessive padding
)

# Transient Drag Card
card_contentTranD = [
    dbc.CardBody(
        [
            html.H2("Transient Drag", className="card-title"),

            html.H1([dcc.Graph(figure=TransientD)])
        ]
    )
]

TranD = dbc.Col([dbc.Card(card_contentTranD, color = 'primary', inverse = True)],xl=4,lg=4,md=4,sm=12)

#Component Transient Tare
TransientTare = go.FigureWidget()
TransientTare = make_subplots(specs=[[{"secondary_y": True}]])
TransientTare.add_scatter(name = "D_Mean", y = dft["D_Mean"], x = dft.index, mode = 'lines', secondary_y=False, line = dict(shape = 'linear', color = 'darkgreen', width = 40)),
TransientTare.add_scatter(name = "Drag Tare", y = dft["Drag Tare Point"], x = dft.index, secondary_y=True, fill = "tonexty"),
TransientTare.add_scatter(name = "Lift Tare", y = dft["Lift Tare Point"], x = dft.index, secondary_y=True,fill = "tonexty"),
#TransientTare.update_xaxes(range = [605,1490]),
TransientTare.update_yaxes(range = [0,200], secondary_y=False)

# Apply Plotly dark theme to the flow data indicators
#TransientTare.update_layout(template="plotly_dark")
TransientTare.update_layout(
    template="plotly_dark",  # Dark theme
    #title="Transient Side Force Over Time",  # Add a title
    #xaxis_title="Index",  # Customize the x-axis label
    #yaxis_title="Side Force Value",  # Customize the y-axis label
    plot_bgcolor='black',  # Set plot background color to black
    paper_bgcolor='black',  # Set paper background color to black
    font=dict(color='white'),  # Set font color to white
    autosize=True,  # Enable autosizing to fit the screen
    margin=dict(l=20, r=20, t=40, b=20)  # Adjust margins to avoid excessive padding
)
# Transient Tare Card
card_contentTare = [
    dbc.CardBody(
        [
            html.H2("Tare", className="card-title"),

            html.H1([dcc.Graph(figure=TransientTare)])
        ]
    )
]
TransTare = dbc.Col([dbc.Card(card_contentTare, color = 'primary', inverse = True)],xl=4,lg=4,md=4,sm=12)

#Lift Per Corner
# Create the Bar chart for Lift Per Corner with a single color for all bars
Indicator_LPCB = go.Figure(go.Bar(
    x=['LLF', 'LRF', 'LLR', 'LRR', 'LF', 'LR'],
    y=[df["LLF"].mean(), df["LRF"].mean(), df["LLR"].mean(), df["LRR"].mean(), df["LF"].mean(), df["LR"].mean()],
    marker=dict(
        color='blue',  # Set a single color for all bars (e.g., blue)
        line=dict(
            color='black',  # Dark edges to add a 3D-like depth
            width=4  # Thicker edges for more pronounced bars
        )
    ),
    orientation='v'  # Vertical bars
))

# Apply Plotly dark theme and additional customizations
# Apply Plotly dark theme and additional customizations
Indicator_LPCB.update_layout(
    template="plotly_dark",
   # title="Lift Per Corner LBF with 3D Projection Effect",
    #xaxis_title="Corner",
    #yaxis_title="Lift Value (LBF)",
    plot_bgcolor='black',  # Set plot background to black
    paper_bgcolor='black',  # Set paper background to black
    font=dict(color='white'), # White font for overall text
    autosize=True,  # Enable autosizing to fit the screen
    margin=dict(l=20, r=20, t=40, b=20)  # Adjust margins to avoid excessive padding
)

# Lift Bar Chart Card Content
card_contentLPCB = [
    dbc.CardBody(
        [
            html.H2("Lift Per Corner LBF", className="card-title"),
            dcc.Graph(figure=Indicator_LPCB)  # Display Plotly figure
        ]
    )
]

# Lift Per Corner Column
LPCB = dbc.Col([dbc.Card(card_contentLPCB, color='primary', inverse=True)], xl=4, lg=4, md=4, sm=12)




#Component Side Force

Indicator_SB = go.Figure(go.Bar(

            y=['SF','SR'],
            x=[df["SF"].mean(), df["SR"].mean()],
            marker=dict(
                color='blue',  # Set a single color for all bars (e.g., blue)
                line=dict(
                    color='black',  # Dark edges to add a 3D-like depth
                    width=4  # Thicker edges for more pronounced bars
                )
            ),
            orientation='h')
            )

# Apply Plotly dark theme to the flow data indicators
#Indicator_SB.update_layout(template="plotly_dark")
# Apply Plotly dark theme and additional customizations
Indicator_SB.update_layout(
    template="plotly_dark",
    #title="Lift Per Corner LBF with 3D Projection Effect",
    #xaxis_title="Corner",
    #yaxis_title="Lift Value (LBF)",
    plot_bgcolor='black',  # Set plot background to black
    paper_bgcolor='black',  # Set paper background to black
    font=dict(color='white'), # White font for overall text
    autosize=True,  # Enable autosizing to fit the screen
    margin=dict(l=20, r=20, t=40, b=20)  # Adjust margins to avoid excessive padding
)
#  SideForce Bar Chart Card
card_contentSB = [
    dbc.CardBody(
        [
            html.H2("Side Force", className="card-title"),

            html.H1([dcc.Graph(figure=Indicator_SB)])
        ]

    )
]
SB = dbc.Col([dbc.Card(card_contentSB, color = 'primary', inverse = True)],xl=4,lg=4,md=4,sm=12)

#Component Moments

Indicator_MB = go.Figure(go.Bar(

            x=['PM','YM', 'RM'],
            y=[df["PM"].mean(), df["YM"].mean(), df["RM"].mean() ],
            marker=dict(
                color='blue',  # Set a single color for all bars (e.g., blue)
                line=dict(
                    color='black',  # Dark edges to add a 3D-like depth
                    width=4  # Thicker edges for more pronounced bars
                )),
                orientation='v')
            )
# Apply Plotly dark theme to the flow data indicators
#Indicator_MB.update_layout(template="plotly_dark")
# Apply Plotly dark theme and additional customizations
Indicator_MB.update_layout(
    template="plotly_dark",
    #title="Lift Per Corner LBF with 3D Projection Effect",
    #xaxis_title="Corner",
    #yaxis_title="Lift Value (LBF)",
    plot_bgcolor='black',  # Set plot background to black
    paper_bgcolor='black',  # Set paper background to black
    font=dict(color='white'), # White font for overall text
    autosize=True,  # Enable autosizing to fit the screen
    margin=dict(l=20, r=20, t=40, b=20)  # Adjust margins to avoid excessive padding
)
#  Moments Bar Chart Card
card_contentMB = [
    dbc.CardBody(
        [
            html.H2("Moment Force", className="card-title"),

            html.H1([dcc.Graph(figure=Indicator_MB)])
        ]
    )
]
MB = dbc.Col([dbc.Card(card_contentMB, color = 'primary', inverse = True)],xl=4,lg=4,md=4,sm=12)


#Component Transient Lift Per Corner
import plotly.graph_objects as go

# Create the figure for the transient lift per corner (LPC)
TransientLPC = go.Figure()

# Add scatter traces for each of the columns: LF, LR, LRF, LRR with custom colors
TransientLPC.add_trace(go.Scatter(x=dft.index, y=dft["LF"], mode='lines', name="LF", line=dict(color='darkgreen')))
TransientLPC.add_trace(go.Scatter(x=dft.index, y=dft["LR"], mode='lines', name="LR", line=dict(color='red')))
TransientLPC.add_trace(go.Scatter(x=dft.index, y=dft["LRF"], mode='lines', name="LRF", line=dict(color='darkblue')))
TransientLPC.add_trace(go.Scatter(x=dft.index, y=dft["LRR"], mode='lines', name="LRR", line=dict(color='purple')))

# Update the x-axis and y-axis ranges
TransientLPC.update_xaxes(range=[605, 1490])  # Adjust x-axis range
TransientLPC.update_yaxes(range=[-10, 60])  # Adjust y-axis range

# Set layout title and axis labels
TransientLPC.update_layout(
    title="Transient Lift Per Corner",
    #xaxis_title="Index",
    #yaxis_title="Lift Force (LBF)",
    template="plotly_dark",  # Optional, for a dark theme
    plot_bgcolor='black',  # Set plot background to black
    paper_bgcolor='black',  # Set paper background to black
    font=dict(color='white'),  # White font for overall text
    autosize=True,  # Enable autosizing to fit the screen
    margin=dict(l=20, r=20, t=40, b=20)  # Adjust margins to avoid excessive padding
)

# To display the plot in Dash:
# If using Dash, you would pass the figure to a dcc.Graph component like so:
# dcc.Graph(figure=TransientLPC)

# Apply Plotly dark theme to the flow data indicators
TransientLPC.update_layout(template="plotly_dark")
#  Transient Lift Per Corner Card
card_contentTranLPC = [
    dbc.CardBody(
        [
            html.H2("Transient Lift Force", className="card-title"),

            html.H1([dcc.Graph(figure=TransientLPC)])
        ]
    )
]
TranLPC = dbc.Col([dbc.Card(card_contentTranLPC, color = 'primary', inverse = True)],xl=4,lg=4,md=4,sm=12)


#Component Transient Side Forcer
TransientSF = go.FigureWidget()
TransientSF.add_scatter(name = "SF", y = dft["SF"], x = dft.index,line=dict(color='darkblue'))
TransientSF.add_scatter(name = "SR", y = dft["SR"], x = dft.index,line=dict(color='red'))
TransientSF.update_xaxes(range = [605,1490]),
TransientSF.update_yaxes(range = [-10,10])
# Apply Plotly dark theme to the flow data indicators
#TransientSF.update_layout(template="plotly_dark")
TransientSF.update_layout(
    template="plotly_dark",  # Dark theme
    #title="Transient Side Force Over Time",  # Add a title
    #xaxis_title="Index",  # Customize the x-axis label
    #yaxis_title="Side Force Value",  # Customize the y-axis label
    plot_bgcolor='black',  # Set plot background color to black
    paper_bgcolor='black',  # Set paper background color to black
    font=dict(color='white'),  # Set font color to white
    autosize=True,  # Enable autosizing to fit the screen
    margin=dict(l=20, r=20, t=40, b=20)  # Adjust margins to avoid excessive padding
)

#  Transient Side Force Card
card_contentTranSF = [
    dbc.CardBody(
        [
            html.H2("Transient Side Force", className="card-title"),

            html.H1([dcc.Graph(figure=TransientSF)])


        ]
    )
]
TranSF = dbc.Col([dbc.Card(card_contentTranSF, color = 'primary', inverse = True)],xl=4,lg=4,md=4,sm=12)

#Component Transient Moments
TransientMF = go.FigureWidget()
TransientMF.add_scatter(name = "PM", y = dft["PM"], x = dft.index,line=dict(color='darkgreen'))
TransientMF.add_scatter(name = "YM", y = dft["YM"], x = dft.index,line=dict(color='darkblue'))
TransientMF.add_scatter(name = "RM", y = dft["RM"], x = dft.index,line=dict(color='red'))
TransientMF.update_xaxes(range = [605,1490]),
TransientMF.update_yaxes(range = [-300,100])
# Apply Plotly dark theme to the flow data indicators
#TransientMF.update_layout(template="plotly_dark")
TransientMF.update_layout(
    template="plotly_dark",  # Dark theme
    #title="Transient Side Force Over Time",  # Add a title
    #xaxis_title="Index",  # Customize the x-axis label
    #yaxis_title="Side Force Value",  # Customize the y-axis label
    plot_bgcolor='black',  # Set plot background color to black
    paper_bgcolor='black',  # Set paper background color to black
    font=dict(color='white'),  # Set font color to white
    autosize=True,  # Enable autosizing to fit the screen
    margin=dict(l=20, r=20, t=40, b=20)  # Adjust margins to avoid excessive padding
)
#  Transient Moment Force Card
card_contentTranMF = [
    dbc.CardBody(
        [
            html.H2("Transient Moment Force", className="card-title"),

            html.H1([dcc.Graph(figure=TransientMF)])
        ]
    )
]
TranMF = dbc.Col([dbc.Card(card_contentTranMF, color = 'primary', inverse = True)],xl=4,lg=4,md=4,sm=12)


#applayout
app.layout = dbc.Container(
    [
        dbc.Row([navbar]),
        dbc.Row(cards,style={'margin-top': '40px', 'margin-bottom': '40px'}),
        dbc.Row([C_LD,TranD,TransTare]),
        dbc.Row([LPCB,SB,MB]),
        dbc.Row([TranLPC,TranSF,TranMF]),

    ],
fluid=True,
style={'backgroundColor': 'black'}
)

if __name__ == "__main__":
    app.run(debug=True)