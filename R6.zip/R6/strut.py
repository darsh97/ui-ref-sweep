


print("Horizontal Buoyancy Correction - Wind Shear Wind Tunnel: Jan-02-2025")

"""
Inputs:

vehYaw (Double): The yaw angle of the vehicle in degrees.
speed (Double): The speed of the vehicle in miles per hour (mph).
vehFrontalArea (Double): The frontal area of the vehicle, which should be dimensionally consistent with other inputs.
strutData (Range): A 1D range of data with the following information

(1) The strut configuration - an integer descriptor of how that strut was installed.  Currently,we have configurations:
    1 for 5 in. above the floor, 
    2 for 7 in. above the floor, and 
    3 for 14 in. above the floor.
    These are valid in the 25-60 deg strut angle range (positive or negative).
    4 is the strut 14 in. above the floor and normal to the flow (strut angle should be passed as 90 deg).
(2) The strut length.
(3) The strut length along the y-axis, i.e., distance from vehicle hookup (or sill edge) to center of T-slot
(4) The strut diameter.  The length and diameter should be dimensionally consistent with one another, and
    with the vehicle frontal area parameter.
(5) The strut's installation angle in degrees, measured as the strut rotates about the load cell tower (+ nose right)

Changed strut_d and strut_L to be assumed as inches coming into this routine; so we convert them to ft here.

Regression equation for the isolated circular cylinder at yaw:
𝐶_(𝐷_𝑐𝑦𝑙 )=𝑐+𝑎_1 𝜓_𝑠𝑡𝑟𝑢𝑡+𝑎_2 𝜓_𝑠𝑡𝑟𝑢𝑡^2+𝑏_1 𝑉_∞+𝑏_2 𝑉_∞^2+𝑏_3 𝑉_∞^3 

Regression coefficients equation for yaw - deg and V - mph for different configurations are as follows:
Conf:	Length	 c	    a1          a2	        b1	        b2	        b3	        2xStd(+/-) Error of Fit
1	    5 in.	-0.818  -0.0289	    -0.000175   +0.00985    -8.52E-05   +2.23E-07	+0.025
2	    7 in.   +0.152  -0.00773    +6.55E-05	-0.00119    -6.65E-06   +4.03E-08	+0.03
3	    14 in.  -0.286  -0.0232     -0.000104	-0.00215    1.38E-05    -3.21E-08	+0.012
4	    14 in.  +1.15   +0	        +0	        +0          +0          +0	        +0.027

Key Variables:
    coeffData: Stores coefficients for different configurations.
    yawCoeff: Coefficients for yaw polynomial evaluation.
    spdCoeff: Coefficients for speed polynomial evaluation.
    constCoeff: Constant coefficient for the configuration.

Important Calculations:
Polynomial evaluations for yaw and speed using jwPolyEvalSgl.
Final drag tare calculation adjusted by strut length, diameter, and vehicle frontal area.
   
"""
"----------------------------------------------------------------------------------------------------------------------"
"Input_Values"
#veh_yaw = 0  #  yaw in degrees
#speed = 86.619144  # speed in mph _ Use corrected Velocity
#FA = 3.041 * 10.7639  # vehicle frontal area in ft^2
#strut_data1 = [3, 4.063*12, 0, 0.104*12, 30.9]
#strut_data2 = [3, 4.063*12, 0, 0.104*12, -30.9]
#strut_data3 = [4, 2.083*12, 0, 0.104*12, -90]
#strut_data4 = [3, 00000*12, 0, 0.104*12, 0.0]
""" strut_data[0]: Strut configuration (2)
    strut_data[1]: Strut length (3.589 feet converted to inches)
    strut_data[2]: Strut length along the y-axis (0 feet converted to inches)
    strut_data[3]: Strut diameter (0.104 feet converted to inches)
    strut_data[4]: Strut installation angle (43 degrees)"""
"""poly_eval Function: Evaluates a polynomial given the coefficients and the value of x.
    This line defines a function named poly_eval that takes two arguments:
    Coefficients (coeffs):The coefficients should be provided in descending order of powers. 
    For example, for the polynomial 𝑎0+𝑎1𝑥+𝑎2𝑥2 and the coeffs would be [a_2, a_1, a_0].
    Value (x):This is the point at which the polynomial is evaluated"""

"----------------------------------------------------------------------------------------------------------------------"

def poly_eval(coeffs, x):

    total = 0
    for i in range(len(coeffs)):
         total += coeffs[i] * (x ** (i + 1))
    return total
"Strut Tare functions"

def strut_tare(veh_yaw, speed, FA, strut_data):

    strut_data[1] /= 12.0  # Strut length - Convert strut dimensions from inches to feet
    strut_data[2] /= 12.0  # Strut length along the y-axis (not used in the provided code)
    strut_data[3] /= 12.0  # Strut diameter - Convert strut dimensions from inches to feet

    # Configuration coefficients
    coeff_data = {
        1: [-0.818, -0.0289, -0.000175, 0.00985, -8.52E-05, 2.23E-07],
        2: [0.152, -0.00773, 6.55E-05, -0.00119, -6.65E-06, 4.03E-08],
        3: [-0.286, -0.0232, -0.000104, -0.00215, 1.38E-05, -3.21E-08],
        4: [1.15, 0, 0, 0, 0, 0]
    }
    """ strut_data (list)
        strut_data[1]: Strut length (initially in inches, to be converted to feet).
        strut_data[2]: Strut length along the y-axis (not used in the provided code).
        strut_data[3]: Strut diameter (initially in inches, to be converted to feet).
        strut_data[4]: Strut installation angle in degrees."""

    config = strut_data[0]
    strut_L = strut_data[1]
    strut_LD = strut_data[2] # Strut length along the y-axis (not used in the provided code)
    strut_d = strut_data[3]
    strut_ang = strut_data[4]

    """Extracting Coefficients for the Given Configuration:
        coeffs = coeff_data[config] - This line accesses the dictionary coeff_data using the key config. 
        The key corresponds to the strut configuration (1, 2, 3, or 4).
        const_coeff = coeffs[0] - Constant Coefficient: coeffs list is the constant coefficient c from the formula.
        yaw_coeffs = coeffs[1:3] - The Yaw Coefficients list will contain these two coefficients: [a1, a2]
        spd_coeffs = coeffs[3:6] - Speed Coefficients will contain these three coefficients: [b1, b2, b3]"""

    coeffs = coeff_data[config]
    const_coeff = coeffs[0]
    yaw_coeffs = coeffs[1:3]
    spd_coeffs = coeffs[3:6]

    """Evaluate Yawpolynomial coefficients
        This function call evaluates polynomial with the coefficients yaw_coeffs at the point -abs(veh_yaw + strut_ang).
        yaw_coeffs: The list of coefficients for the yaw polynomial. 
        For example, if yaw_coeffs = [-0.00773, 6.55E-05], the polynomial is -0.00773 + 6.55E-05 * x.
        -abs(veh_yaw + strut_ang): The value of x at which the polynomial is evaluated. 
        This value is the negative absolute value of the sum of the vehicle yaw angle (veh_yaw) 
        and the strut installation angle (strut_ang).
        This is done because the strut drag is symmetric about 0 degrees yaw, so the absolute value is used to 
        ensure the angle is positive, and the negative sign ensures it fits the regression model.
        Similarly, the speed polynomial is evaluated using the speed value in mph.

        Visualizing the Polynomial Evaluation:
        yaw_coeffs = [-0.00773, 6.55E-05], veh_yaw = 30.0 degrees,strut_ang = 15.0 degrees
        -abs(veh_yaw + strut_ang) = -abs(30.0 + 15.0) = -45.0
        The yaw polynomial evaluation is -0.00773 + 6.55E-05 * (-45.0).
        spd_coeffs = [-0.00119, -6.65E-06, 4.03E-08] & speed = 60.0 mph
        The speed polynomial evaluation is -0.00119 + (-6.65E-06) * 60.0 + 4.03E-08 * (60.0^2)."""

    yaw_val = poly_eval(yaw_coeffs, -abs(veh_yaw + strut_ang))
    spd_val = poly_eval(spd_coeffs, speed)

    # Calculate strut tare
    strut_tare_value = yaw_val + spd_val + const_coeff
    strut_tare_value *= strut_L * strut_d / FA

    return strut_tare_value

def strut_correction_execution(veh_yaw, speed, FA, strut_data1, strut_data2, strut_data3, strut_data4):
    strut_tare_value1 = strut_tare(veh_yaw, speed, FA, strut_data1)
    strut_tare_value2 = strut_tare(veh_yaw, speed, FA, strut_data2)
    strut_tare_value3 = strut_tare(veh_yaw, speed, FA, strut_data3)
    strut_tare_value4 = strut_tare(veh_yaw, speed, FA, strut_data4)
    strut_tare_total = strut_tare_value1 + strut_tare_value2 + strut_tare_value3 + strut_tare_value4

    print(f"Strut Tare1: {strut_tare_value1}")
    print(f"Strut Tare2: {strut_tare_value2}")
    print(f"Strut Tare3: {strut_tare_value3}")
    print(f"Strut Tare4: {strut_tare_value4}")
    print(f"Strut Tare Total: {strut_tare_total}")
    "----------------------------------------------------------------------------------------------------------------------"
    
    return strut_tare_total, strut_tare_value1, strut_tare_value2, strut_tare_value3, strut_tare_value4
    