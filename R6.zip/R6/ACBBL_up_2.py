# -*- coding: utf-8 -*-
"""
Created on Thu Feb 13 10:48:11 2025

@author: AdnanShahriar(Contra
"""

# -*- coding: utf-8 -*-
"""
Created on Thu Feb  6 11:24:14 2025

@author: AdnanShahriar(Contra
"""

# -*- coding: utf-8 -*-
"""
Created on Thu Jan 23 13:50:07 2025

"""

# -*- coding: utf-8 -*-
"""
Created on Wed Jan 22 10:30:48 2025

@author: RahulJoshi

Airspeed Calibration :

    Airspeed at Windshear under normal test conditions is controlled by dynamic pressure, static pressure, total temperature, 
    and relative humidity.Additionally Windshear provides 2 different airspeed control variants, plenum and nozzle method.
    The measured dynamic and static pressures are pushed through a calibration curve to produce calibrated dynamic and static 
    pressures.



Boundary Layer Characterization:

    Boundary layer profiles are as much a function of geometry and test set up as they are of the mass flow 
    removal that precedes them. For this reason, this process is defined as a characterization rather than a 
    calibration.

"""

import math
import pandas as pd

# ------------------------------------------------------------------------------

'''
AIRSPEED CALIBRATION 

'''

# Static Pressure Calibration

# P1T-1001A

  
def ACBBL_Execution(dd0, dd1, primary_dd0, primary_dd1, primary_dd2, secondary_dd0, secondary_dd1, secondary_dd2, rho, method_In, dynp_meas_P, dynp_meas_N, static_pres, tunnel_air_temp, rel_humidity,delta_Pp, Area):
    
    if method_In==0:
        method = "primary"
    else:
        method = "secondary"
            
        
    
    def calculate_p_infinity(q_meas, ps_meas):
        p_infinity = dd1 * q_meas + dd0 + ps_meas
        return p_infinity


    # Dynamic Pressure Calibration

    def calculate_pT_infinity(q_meas,  constants, method='secondary'):
        # Constants for Primary and Secondary

        constants_selected = constants[method]

        if method == 'primary':
            del_P_t_infinity = q_meas ** 2 * constants_selected['dd2'] + q_meas * constants_selected['dd1'] + \
                               constants_selected['dd0']
        elif method == 'secondary':
            del_P_t_infinity = q_meas ** 2 * constants_selected['dd2'] + q_meas * constants_selected['dd1'] + \
                               constants_selected['dd0']

        return (del_P_t_infinity) # FUTURE CORRECTION


    # ------------------------------------------------------------------------------

    def calculate_qts(p_infinity, del_P_t_infinity, gamma=1.4):
        """
        Calculate the compressible test section dynamic pressure (qts).

        Parameters:
        - p_infinity (float): The calibrated static pressure (p∞) in Pascals (Pa)
        - delta_p_t_infinity (float): The calibrated test section differential pressure (ΔPt_infinity) in Pascals (Pa)
        - gamma (float): The specific heat ratio (γ) for dry air, default 1.4

        Returns:
        - qTS (float): The compressible test section dynamic pressure (qTS) in Pascals (Pa)
        """
        qts = ((gamma * p_infinity) / (gamma - 1)) * (((del_P_t_infinity / p_infinity) + 1) ** ((gamma - 1) / gamma) - 1)
        return qts


    def calculate_mach_number(q_ts, p_infinity, gamma=1.4):
        """
        Calculate the Mach number based on the compressible test section dynamic pressure (qTS) and static pressure (p∞).

        Parameters:
        - q_ts (float): The compressible test section dynamic pressure (qTS) in Pascals (Pa)
        - p_infinity (float): The static pressure (p∞) in Pascals (Pa)
        - gamma (float): The specific heat ratio (γ) for dry air, default 1.4

        Returns:
        - mach_number (float): The Mach number
        """
        # Original
        mach_number = math.sqrt(2 * qts / (gamma * p_infinity))
        
        print(mach_number)

        return mach_number


    def calculate_static_temperature(T_t_infinity, mach_number, gamma=1.4):
        """
        Calculate the static temperature from the total temperature and Mach number.

        Parameters:
        - T_t_infinity (float): The flow total temperature (in K) measured in the stilling chamber (Tt∞) in Kelvin (K)
        - mach_number (float): The Mach number
        - gamma (float): The specific heat ratio (γ) for dry air, default 1.4

        Returns:
        - T_sK (float): The flow static temperature (TsK) in Kelvin (K)
        """
        T_sK = T_t_infinity / (1 + ((gamma - 1) / 2 * mach_number ** 2))

        return T_sK


    def calculate_water_vapor_partial_pressure(theta, T_sC):
        """
        Calculate the water vapor partial pressure based on relative humidity and static temperature in Celsius.

        Parameters:
        - theta (float): The relative humidity as a fraction (0 to 1)
        - T_sC (float): The flow static temperature in Celsius (°C)

        Returns:
        - e (float): The water vapor partial pressure (Pa)
        """
        e_max = 100 * 6.11 * 10 ** (7.5 * T_sC / (237.3 + T_sC))
        e = theta * e_max
        return e


    def calculate_airspeed(qts, p_infinity, T_sK, e, rho, R=287.05, Rw=461.9):
        """
        Calculate the airspeed (UTS) using the compressible test section dynamic pressure and thermodynamic properties.

        Parameters:
        - q_ts (float): The compressible test section dynamic pressure (qTS) in Pascals (Pa)
        - p_infinity (float): The static pressure (p∞) in Pascals (Pa)
        - T_sK (float): The flow static temperature (TsK) in Kelvin (K)
        - e (float): The water vapor partial pressure (Pa)
        - R (float): The gas constant for dry air in m^2/s^2K, default 287.05

        Returns:
        - UTS (float): The airspeed (UTS) in meters per second (m/s)
        """
        #1.1561590970606965
        # rho = (p_infinity / (R * T_sK)) * (1 - (1-(R / Rw) * (e / p_infinity))
        #ce=R/Rw
        #rho = p_infinity / (287.05 * T_sK) * (1 - 0.3785 * (e / p_infinity))
        # print("density: ", ce)
        #    uts = math.sqrt(2 * qts / (p_infinity * R * T_sK * (1 - 0.3785 * e / p_infinity)))
        # rho =1.15
        uts = math.sqrt(2 * qts / rho)
        return uts


    # ------------------------------------------------------------------------------
    '''
    BOUNDARY LAYER CHARACTERIZATION
    '''
    """
    QSP - Volumetric Flow Rate Set Point ( in cubic feet per minute) is a function of the controlling calculated calibrated thermodynamic 
    test section dynamic pressure feedback (qts) be it plenum or nozzle method
    """


    def calculate_qsp(qts, Area, method='secondary'):
        # Constants for Primary and Secondary
        constants = {
            'primary': {
                'A': -0.001851,
                'B': 16.5567,
                'C': 11129.6,
                'D': 10,
                'E': 250
            },
            'secondary': {
                'A': 0,
                'B': 294.9,
                'C': 0,
                'D': 200,
                'E': 0.001921935
            }
        }

        # Select the correct constants based on the method (Primary or Secondary)
        constants_selected = constants[method]

        # Check if qTS is less than the constant D
        if qts < constants_selected['D']:
            QSP = (constants_selected['E'] * qts)
        else:
            # If qTS is greater than or equal to D, calculate QSP based on the equations
            if method == 'primary':
                QSP = (constants_selected['A'] * qts ** 2 + constants_selected['B'] * qts + constants_selected['C'])
            elif method == 'secondary':
                QSP = (constants_selected['A'] * qts + constants_selected['B'] * math.sqrt(qts + constants_selected['C']))

        return QSP


    # ------------------------------------------------------------------------------

    """
    QFB - Volumetric Flow Rate Feedback (( in cubic feet per minute)) is a function of flow element geometry, the pump differential pressure (delta_Pp)
    across that flow element in inches of water and atmospheric conditions.
    """


    def calculate_qfb(delta_Pp, rho, method='secondary'):
        # Constants for Primary and Secondary
        constants = {
            'primary': {
                'K1': 34.76,
                'K2': 0.99034,
                'A': 5.197
            },
            'secondary': {
                'K1': 13.13,
                'K2': 0.98459,
                'A': 5.197
            }
        }

        # Select the correct constants based on the method (Primary or Secondary)
        constants_selected = constants[method]

        # rho = 0.07235401 * 16.01  # constant density in pound per cubic foot converted to kg/m3

        if method == 'primary':
            QFB = 60 * constants_selected['K1'] * constants_selected['K2'] * math.sqrt(
                (constants_selected['A'] * delta_Pp) / rho)
        elif method == 'secondary':
            QFB = 60 * constants_selected['K1'] * constants_selected['K2'] * math.sqrt(
                (constants_selected['A'] * delta_Pp) / rho)

        return QFB


    # ------------------------------------------------------------------------------

    """

    Omega_SP - Pump Fan Speed Set Point (( in rpm)) - The wind tunnel control system inputs the volumetric flow rate set point (QSP) 
    into a PID loop that outputs the pump fan speed set point (Omega_SP). Linear fan speed can be determined by dividing 
    the volumetric flow rate set point (QSP) in cfm by the fan area (A) in squared feet. The rotational speed is 
    therefore the linear speed divided by the radius (r) in feet.

    """


    def calculate_omega_sp(QSP, method='secondary'):
        # Constants for Primary and Secondary
        constants = {
            'primary': {
                'r': 1.72,  # radius in ft
                'A': 9.31,  # fan area in ft2
                'f': 0.025  # constant
            },
            'secondary': {
                'r': 1.23,  # radius in ft
                'A': 4.79,  # fan area in ft2
                'f': 0  # constant
            }
        }

        # Select the correct constants based on the method (Primary or Secondary)
        constants_selected = constants[method]

        if method == 'primary':
            Omega_SP = ((1 / constants_selected['r']) * ((QSP * Area / 471.9497) / constants_selected['A'])) - (
                        constants_selected['f'] * QSP)
            
        elif method == 'secondary':
            Omega_SP = ((1 / constants_selected['r']) * ((QSP * Area / 471.9497) / constants_selected['A'])) - (
                        constants_selected['f'] * QSP)


# =============================================================================
#         Omega_SP = ((1 / constants_selected['r']) * (QSP / constants_selected['A'])) - (
#                         constants_selected['f'] * QSP)            
# =============================================================================

        return Omega_SP

    
    # ------------------------------------------------------------------------------



# =============================================================================
#     print("p_infinity : ", p_infinity)
# =============================================================================

        # Constants for Primary and Secondary
    constants = {
        'primary': {
            'dd0': primary_dd0,
            'dd1': primary_dd1,
            'dd2': primary_dd2
        },
        'secondary': {
            'dd0': secondary_dd0,
            'dd1': secondary_dd1,
            'dd2': secondary_dd2
        }
    }
    
    print("Constants=", constants)
    print("Method=", method)


    if method == "secondary":
        dynp_meas = dynp_meas_P
    else:
        dynp_meas = dynp_meas_N

    q_meas = dynp_meas

    ps_meas = static_pres

    p_infinity = calculate_p_infinity(q_meas, ps_meas)  # Calibrated Static pressure (p∞) in Pascals (Pa)

    del_p_t_infinity = calculate_pT_infinity(q_meas, constants,
                                             method)  # Calibrated Differential pressure (ΔPt) in Pascals (Pa)



    T_t_infinity = tunnel_air_temp + 273  # Measured flow total temperature (in K) measured in the stilling chamber (Tt∞) in Kelvin (K)

    theta = rel_humidity  # is the relative humidity expressed in a fraction (0 to 1) measured in the stilling chamber


# =============================================================================
    print("del_p_t_infinity : ", del_p_t_infinity)
# =============================================================================


    # Step 1: Calculate compressible test section dynamic pressure (qts)
    qts = calculate_qts(p_infinity, del_p_t_infinity)

# =============================================================================
#     print(f"Compressible test section dynamic pressure qts is: {qts:.2f} Pa")
# =============================================================================

    # Step 2: Calculate Mach number (M)
    mach_number = calculate_mach_number(qts, p_infinity)

    # Step 3: Calculate static temperature (TsK) from total temperature and Mach number
    T_sK = calculate_static_temperature(T_t_infinity, mach_number)

    T_sC = T_sK - 273  # Static temperature (TsC) in Celsius (°C)

    # Step 4: Calculate water vapor partial pressure (e)
    e = calculate_water_vapor_partial_pressure(theta, T_sC)

    # Step 5: Calculate airspeed (UTS)
    uts = calculate_airspeed(qts, p_infinity, T_sK, e, rho)

    uts_mph = uts * 2.236936

# =============================================================================
#     print("#-----------------------------------------------------------------#")
# 
#     print("pump differential pressure", delta_Pp)
#     print(f"Compressible test section dynamic pressure qts is: {qts:.2f} Pa")
#     print(f"Mach Number is: {mach_number:.3f} ")
#     print(f"Static temperature is: {T_sK:.2f} K ")
#     print(f"water vapor partial pressure is: {e:.2f} Pa")
#     print(f"The airspeed UTS is: {uts_mph:.3f} mph")
# =============================================================================

    QSP = calculate_qsp(qts, method) * Area / 471.9497
    QFB = calculate_qsp(delta_Pp, method)
    OSP = calculate_omega_sp(QSP, method)

# =============================================================================
#     print("#-----------------------------------------------------------------#")
# 
#     print(f"The Volumetric Flow Rate Set Point (QSP) is: {QSP} cfm")
#     print(f"The Volumetric Flow Rate Feedback (QFB) is: {QFB} cfm")
#     print(f"The Pump Fan Speed Set Point (Omega_SP) is: {OSP} rpm")
# 
# =============================================================================
    # RHO is coming from me

    results = {
        "Dynamic Pressure Measured (Pa)": dynp_meas,
        "Static Pressure (Pa)": static_pres,
        "Tunnel Air Temperature (C)": tunnel_air_temp,                  # Dial 5
        "Relative Humidity": rel_humidity,
        "p_infinity (Pa)": p_infinity,                                  # Dial 4
        "del_p_t_infinity (Pa)": del_p_t_infinity,
        "Compressible Test Section Dynamic Pressure (qts, Pa)": qts,    # Dial 2
        "Mach Number": mach_number,
        "Static Temperature (K)": T_sK,
        "Static Temperature (C)": T_sC,
        "Water Vapor Partial Pressure (Pa)": e,
        "Airspeed UTS (mph)": uts_mph,                                  # Dial 1
        "Volumetric Flow Rate Set Point": QSP,      
        "Volumetric Flow Rate Feedback": QFB,                           # Dial 3
        "Pump Fan Speed Set Point": OSP
    }
    
    return results
    
    
    
if __name__ == "__main__":    
    
    dd0 = 1.21856e+002
    dd1 = -5.11334e-003
    
    
    # ------------------------------------------------------------------------------
    # ------------------------------------------------------------------------------
    # ------------------------------------------------------------------------------
    
    # Import Data D1 Recalc
    
    df = pd.read_table(
        "D1_R1_Recalc.asc",
        encoding='ISO-8859-1', skiprows=[0, 1, 2, 4], usecols=range(1, 651))
    
    results = []  # save data in this list for exporting later to csv
    
    total_runs = len(df)
    
    # for i in range(total_runs):
      
    i=1    
      
    primary_dd0 = -3.30614
    primary_dd1 = 1.02503 
    primary_dd2 = 0
    secondary_dd0 = 0.987069
    secondary_dd1 = 1.01049
    secondary_dd2 = 0
    

    rho = 1.15
    
    method = 1
    
    
    
    run = df["Run Number"].iloc[i]

    print("#------------------------------------------------------------------#")

    print("run", run)

    print("#------------------------------------------------------------------#")

    #    dynp_meas = df["Dynamic_Press_Plenum_Method"].iloc[i] / 0.020885   # measured dyn pressure convert this from Psf to Pa


    delta_Pp = df["Plenum_Stilling_Chamber_Diff_Press"].iloc[
                   i] / 0.0040146  # Measured value of pump differential pressure

    #    delta_Pp = df["Main_Fan_Diff_Press"].iloc[i] / 0.0040146 # Measured value of pump differential pressure

    Area = df["WTCS_SM"].iloc[i]



    dynp_meas_P = 18.217407 * 47.880258888889
    dynp_meas_N = 17.022932 * 47.880258888889
        
    # print("Dynamic Pressure Measured :", dynp_meas)

    static_pres = 395.923645 / 0.0040146  # measured static pressure in H2 converted to Pa

    print("Static Pressure Measured:", static_pres)

    tunnel_air_temp = ((75.592636 - 32) * 5/9) + 273.15 # measured tunnel temperature convert this from def F to deg C
    tunnel_air_temp_c = ((75.592636 - 32) * 5 / 9)  # measured tunnel temperature convert this from def F to deg C
    print("Tunnel Air Temperature :", tunnel_air_temp)

    rel_humidity = 37.675339 / 100  # measured relative humidity convert this to fraction between 0 to 1

    print("Relative Humidity :", rel_humidity)
    
    results = ACBBL_Execution(dd0, dd1, primary_dd0, primary_dd1, primary_dd2, secondary_dd0, secondary_dd1, secondary_dd2, rho, method, dynp_meas_P, dynp_meas_N, static_pres, tunnel_air_temp, rel_humidity,delta_Pp, Area)
        