# -*- coding: utf-8 -*-
"""
Created on Wed Jan 29 15:42:06 2025

@author: AdnanShahriar(Contra
"""
import pandas as pd
import numpy as np
from Cp_Table_data import *
from Supporting_files import linear_interpolation
import matplotlib.pyplot as plt


def wake_distortion_exe(CDm1,CDm2,XM, WB, FOH, n,Plotter,case):
    
    if case==1:
        [cd_corrected, Xs_WD, target_x_values_array, CD_Dist1, CD_Dist2] = wake_distortion_exe_new(CDm1,CDm2,XM, WB, FOH, n,Plotter)
    else:
        [cd_corrected, Xs_WD, target_x_values_array, CD_Dist1, CD_Dist2] = wake_distortion_exe_previous(CDm1,CDm2,XM, WB, FOH, n, Plotter) 

    return cd_corrected, Xs_WD, target_x_values_array, CD_Dist1, CD_Dist2


def wake_distortion_exe_new(CDm1,CDm2,XM, WB, FOH, n,Plotter):

    cp_table    =cp_table_data()
    X           =cp_table[:, 0]
    CP1T        =cp_table[:, 1]
    CP2T        =cp_table[:, 2]
    
    # Calculate front bumper position
    xFrtBmpr = XM - WB / 2 - FOH
    xRearBmpr = xFrtBmpr + WB + FOH
    vehLen = xRearBmpr - xFrtBmpr
    
    # vehLen          =   x_rear_bmpr - x_front_bmpr
    Point1          =   xRearBmpr + vehLen / 2
    
    
    G1  =   get_dx_CP1(Point1)
    G2  =   get_dx_CP2(Point1)
    der=(CDm2-CDm1)/(G2-G1)
    
    sign = 0
    if der<0:
        sign = 1 
    elif der>0:
        sign = -1 
        
    print(sign)
    
    CP1_xfbr=get_CP1(xFrtBmpr)
    CP2_xfbr=get_CP2(xFrtBmpr)
    
     
    
    target_x = np.min(X)
    increment = 0.0001
    sign_change = False
    count = 0
    
    # Perform linear interpolation in a loop
    while not sign_change:
        target_x += increment
        
        if target_x > np.max(X):
            print("FAILED!!!!")
            break        
    
        CP1_Det = linear_interpolation(X, CP1T, target_x)
        a = (CDm1 - sign * (CP1_xfbr - CP1_Det)) / n
    
        CP2_Det = linear_interpolation(X, CP2T, target_x)
        b = (CDm2 - sign * (CP2_xfbr - CP2_Det)) / n
    
        # Compute the difference
        diff = a - b
    
        # Determine new sign
        new_sign = np.sign(diff)  # np.sign() returns -1, 0, or 1
    
        # Check if sign has flipped
        if count > 0 and new_sign != sign_old:
            print(f"Sign flipped at iteration {count}, target_x = {target_x}")
            sign_change = True
            break  # Stop the loop when sign flips
    
        # Update previous sign
        sign_old = new_sign
    
        count += 1
        
    cd_corrected=a
    Xs_WD = target_x

    
    # =============================================================================
    # Generate the target_x values efficiently
    if Plotter == 1:
        increment = 0.1
        target_x_values_array = np.arange(np.min(X), np.max(X), increment)
    
        CD_Dist1 = np.zeros_like(target_x_values_array)
        CD_Dist2 = np.zeros_like(target_x_values_array)
     
        for i, target_x in enumerate(target_x_values_array):
            CP1_Det = linear_interpolation(X, CP1T, target_x)
            CD_Dist1[i] = (CDm1 - sign * (CP1_xfbr - CP1_Det)) / n    
     
            CP2_Det = linear_interpolation(X, CP2T, target_x)
            CD_Dist2[i] = (CDm2 - sign * (CP2_xfbr - CP2_Det)) / n   
            
    else:
        target_x_values_array = None
        CD_Dist1 = None
        CD_Dist2 = None
    # =============================================================================
        
    return cd_corrected, Xs_WD, target_x_values_array, CD_Dist1, CD_Dist2
        
          
def wake_distortion_exe_previous(CDm1,CDm2,XM, WB, FOH, n, Plotter):

    # Define the data
    data = {
        "X": [0.0762, 0.3048, 0.9144, 1.2192, 1.524, 1.8288, 2.4384, 3.048, 4.064, 4.8768,
              5.334, 5.7912, 6.096, 6.4008, 6.858, 7.1628, 7.4676, 7.7597, 8.128, 8.4582,
              8.6868, 8.8392, 8.9916, 9.144, 9.2964, 9.4488, 10.0584],
        "Cp1": [0.0035, 0.0057, 0.0065, 0.0044, 0.0042, 0.0035, 0.0017, 0.0009, 0.001, 0.0009,
                -0.0002, 0.0001, -0.0011, -0.0011, -0.0012, -0.0017, -0.0019, -0.0028, -0.0056,
                -0.0067, -0.0061, -0.0056, -0.0053, -0.0041, -0.0022, -0.0003, 0.0018],
        "Cp2": [-0.0005, 0.0024, 0.0015, 0.001, 0.0018, 0.0008, -0.0024, -0.0019, -0.0024,
                -0.0018, 0, -0.0011, -0.0007, 0.0004, 0.0006, 0.0011, 0.0026, 0.0038, 0.0075,
                0.0137, 0.0179, 0.0206, 0.0242, 0.0309, 0.0358, 0.0409, 0.0715]
    }    

    # Create DataFrame
    df = pd.DataFrame(data)


    # Calculate front bumper position
    xFrtBmpr = XM - WB / 2 - FOH
    xRearBmpr = xFrtBmpr + WB + FOH
    vehLen = xRearBmpr - xFrtBmpr
    
    # Define a function to interpolate Cp at a given x
    def interpolate_cp(x, cp, xp):
        return np.interp(x, xp, cp)
    
    # Calculate pressure gradients at the rear bumper position for both gradients
    G1 = (interpolate_cp(xRearBmpr + vehLen / 2, df['Cp1'], df['X']) - interpolate_cp(XM, df['Cp1'], df['X'])) / (xRearBmpr + vehLen / 2 - XM)
    G2 = (interpolate_cp(xRearBmpr + vehLen / 2, df['Cp2'], df['X']) - interpolate_cp(XM, df['Cp2'], df['X'])) / (xRearBmpr + vehLen / 2 - XM)
    
    # Determine sign for corrections based on pressure gradients
    signChoice = -np.sign((CDm2 - CDm1) / (G2 - G1))
    
    # Calculate the adjusted coefficients
    df['CDC1'] = CDm1 - signChoice * (interpolate_cp(xFrtBmpr, df['Cp1'], df['X']) - df['Cp1'])
    df['CDC2'] = CDm2 - signChoice * (interpolate_cp(xFrtBmpr, df['Cp2'], df['X']) - df['Cp2'])
    
    # Find the point of intersection
    diff = (df['CDC1'] - df['CDC2']).abs()
    intersection_index = diff.idxmin()
    xIntersect = df.loc[intersection_index, 'X']
    yIntersect = (df.loc[intersection_index, 'CDC1'] + df.loc[intersection_index, 'CDC2']) / 2


    cd_corrected = yIntersect
    Xs_WD = xIntersect
    
    target_x_values_array = np.array(data["X"])
    CD_Dist1 = np.array(df['CDC1'])
    CD_Dist2 = np.array(df['CDC2'])

    return cd_corrected, Xs_WD, target_x_values_array, CD_Dist1, CD_Dist2
        
        
if __name__ == "__main__":        
        
    
    # Constants and given values
    XM = 4.067  # distance from NEP to center of balance
    WB = 3.449  # vehicle wheelbase
    FOH = 0.9   # vehicle front overhang

    n=1
    
    CDm1 = 0.34891143 # 0.34891143008
    CDm2 = 0.348525929 #0.333805929016


    [cd_corrected, Xs_WD, target_x_values_array, CD_Dist1, CD_Dist2]=wake_distortion_exe_new(CDm1,CDm2,XM, WB, FOH, n,1)

    # Plotting
    plt.figure(figsize=(10, 6))
    plt.plot(target_x_values_array, CD_Dist1, label='Corrected CD1')
    plt.plot(target_x_values_array, CD_Dist2, label='Corrected CD1')
    plt.scatter(Xs_WD, cd_corrected, color='red', zorder=5)
    plt.legend()
    # Set x and y limits
    #plt.xlim(0,10)  # X-axis limit
    #plt.ylim(0.33, 0.36)      
    plt.grid(True)
    plt.show()
    
    
    [cd_corrected, Xs_WD, target_x_values_array, CD_Dist1, CD_Dist2]=wake_distortion_exe_previous(CDm1,CDm2,XM, WB, FOH, n, 1)    
    
    # Plotting
    # plt.scatter(Xs_WD, cd_corrected, color='red', zorder=5)

    plt.figure(figsize=(10, 6))
    plt.plot(target_x_values_array, CD_Dist1, label='Corrected CD1')
    plt.plot(target_x_values_array, CD_Dist2, label='Corrected CD1')
    plt.scatter(Xs_WD, cd_corrected, color='red', zorder=5)
    plt.legend()
    # Set x and y limits
    #plt.xlim(0,10)  # X-axis limit
    #plt.ylim(0.33, 0.36)      
    plt.grid(True)
    plt.show()


